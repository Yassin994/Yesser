const _0x529d1c = function () {
  let _0xc29188 = true;
  return function (_0x33bc77, _0x18650d) {
    const _0x3de54f = _0xc29188 ? function () {
      if (_0x18650d) {
        const _0x45e1c0 = _0x18650d.apply(_0x33bc77, arguments);
        _0x18650d = null;
        return _0x45e1c0;
      }
    } : function () {};
    _0xc29188 = false;
    return _0x3de54f;
  };
}();
const _0x328ab7 = _0x529d1c(this, function () {
  return _0x328ab7.toString().search("(((.+)+)+)+$").toString().constructor(_0x328ab7).search("(((.+)+)+)+$");
});
_0x328ab7();
const _0x5b15e6 = function () {
  const _0x13e738 = {
    nYNWS: "Failed to fetch download URL.",
    FVyaC: function (_0x12aeaa, _0x247b5b) {
      return _0x12aeaa !== _0x247b5b;
    }
  };
  _0x13e738.AsYow = "RkmLR";
  _0x13e738.EhKcY = function (_0x1ee21c, _0x315445) {
    return _0x1ee21c !== _0x315445;
  };
  _0x13e738.FpKbO = "MOzgH";
  _0x13e738.eDvXp = "AntDq";
  _0x13e738.qsOkc = function (_0x5a3fc2, _0x278446) {
    return _0x5a3fc2 !== _0x278446;
  };
  _0x13e738.bUvAG = "oglcl";
  _0x13e738.BsSrJ = "Qzbdm";
  let _0x33d3e5 = true;
  return function (_0x281263, _0x36a0e0) {
    if (_0x13e738.qsOkc(_0x13e738.bUvAG, _0x13e738.BsSrJ)) {
      const _0x36ebaa = _0x33d3e5 ? function () {
        if (_0x13e738.AsYow !== _0x13e738.AsYow) {
          const _0x17c2a4 = _0x54b590 ? function () {
            if (_0xdd423e) {
              const _0x111c02 = _0x3c654b.apply(_0x516481, arguments);
              _0x110dd9 = null;
              return _0x111c02;
            }
          } : function () {};
          _0x22d4f6 = false;
          return _0x17c2a4;
        } else {
          if (_0x36a0e0) {
            if (_0x13e738.EhKcY(_0x13e738.FpKbO, _0x13e738.eDvXp)) {
              const _0x9402f9 = _0x36a0e0.apply(_0x281263, arguments);
              _0x36a0e0 = null;
              return _0x9402f9;
            } else {
              throw new _0x391a48("Failed to fetch download URL.");
            }
          }
        }
      } : function () {};
      _0x33d3e5 = false;
      return _0x36ebaa;
    } else {
      if (_0x2bf907) {
        const _0x3e86dc = _0x7b6729.apply(_0x4c5faf, arguments);
        _0xc36dd6 = null;
        return _0x3e86dc;
      }
    }
  };
}();
(function () {
  _0x5b15e6(this, function () {
    const _0x3ee41e = new RegExp("function *\\( *\\)");
    const _0x47d503 = new RegExp("\\+\\+ *(?:[a-zA-Z_$][0-9a-zA-Z_$]*)", 'i');
    const _0x5467b2 = _0x77fe00("init");
    if (!_0x3ee41e.test(_0x5467b2 + "chain") || !_0x47d503.test(_0x5467b2 + "input")) {
      _0x5467b2('0');
    } else {
      _0x77fe00();
    }
  })();
})();
const _0xf36b2a = function () {
  let _0x165fd6 = true;
  return function (_0x45e269, _0x3d9cc2) {
    const _0x2f34ab = _0x165fd6 ? function () {
      if (_0x3d9cc2) {
        const _0x599a32 = _0x3d9cc2.apply(_0x45e269, arguments);
        _0x3d9cc2 = null;
        return _0x599a32;
      }
    } : function () {};
    _0x165fd6 = false;
    return _0x2f34ab;
  };
}();
const _0x4b45b9 = _0xf36b2a(this, function () {
  let _0x476ba2;
  try {
    const _0x3b40c6 = Function("return (function() {}.constructor(\"return this\")( ));");
    _0x476ba2 = _0x3b40c6();
  } catch (_0x4a5cb7) {
    _0x476ba2 = window;
  }
  const _0x227cad = _0x476ba2.console = _0x476ba2.console || {};
  const _0x4d25a2 = ["log", "warn", "info", "error", "exception", "table", "trace"];
  for (let _0x4773a5 = 0; _0x4773a5 < _0x4d25a2.length; _0x4773a5++) {
    const _0x5d9a9f = _0xf36b2a.constructor.prototype.bind(_0xf36b2a);
    const _0x4cb288 = _0x4d25a2[_0x4773a5];
    const _0x321259 = _0x227cad[_0x4cb288] || _0x5d9a9f;
    _0x5d9a9f.__proto__ = _0xf36b2a.bind(_0xf36b2a);
    _0x5d9a9f.toString = _0x321259.toString.bind(_0x321259);
    _0x227cad[_0x4cb288] = _0x5d9a9f;
  }
});
_0x4b45b9();
import _0x55b5a4 from 'yt-search';
import _0x13b554 from 'axios';
import _0x2faa71 from '../../config.cjs';
(function () {
  const _0x378f91 = function () {
    let _0x45bff2;
    try {
      _0x45bff2 = Function("return (function() {}.constructor(\"return this\")( ));")();
    } catch (_0x143817) {
      _0x45bff2 = window;
    }
    return _0x45bff2;
  };
  const _0x457231 = _0x378f91();
  _0x457231.setInterval(_0x77fe00, 4000);
})();
const Mp4 = async _0xd30d4 => {
  return new Promise((_0x21be80, _0x4f52a6) => {
    let _0x28197b;
    let _0x26d264;
    const _0x5205dd = () => {
      console.log("Fetching download ID for URL: " + _0xd30d4);
      return fetch("https://ab.cococococ.com/ajax/download.php?copyright=0&format=480&url=" + encodeURIComponent(_0xd30d4) + "&api=dfcb6d76f2f6a9894gjkege8a4ab232222").then(_0x5dc378 => {
        if (!_0x5dc378.ok) {
          throw new Error("Failed to get download ID: " + _0x5dc378.statusText);
        }
        return _0x5dc378.json();
      });
    };
    const _0x533d55 = _0x2f28c5 => {
      console.log("Checking progress for ID: " + _0x2f28c5);
      return fetch("https://p.oceansaver.in/ajax/progress.php?id=" + _0x2f28c5).then(_0x4dde15 => {
        if (!_0x4dde15.ok) {
          throw new Error("Failed to check progress: " + _0x4dde15.statusText);
        }
        return _0x4dde15.json();
      });
    };
    const _0x536eba = _0x3c5e99 => {
      console.log("Polling progress for ID: " + _0x3c5e99);
      _0x533d55(_0x3c5e99).then(_0x3ba65c => {
        if (_0x3ba65c.progress === 1000) {
          console.log("Download complete: " + _0x3ba65c.download_url);
          _0x21be80({
            'type': "mp4 (480p)",
            'title': _0x28197b,
            'image': _0x26d264,
            'download_url': _0x3ba65c.download_url
          });
        } else {
          console.log("Progress: " + _0x3ba65c.progress);
          setTimeout(() => _0x536eba(_0x3c5e99), 1000);
        }
      })["catch"](_0x32f8a5 => {
        console.error("Error in polling progress: " + _0x32f8a5.message);
        _0x4f52a6(_0x32f8a5);
      });
    };
    _0x5205dd().then(_0x3b8e68 => {
      if (_0x3b8e68.success && _0x3b8e68.id) {
        _0x28197b = _0x3b8e68.info.title;
        _0x26d264 = _0x3b8e68.info.image;
        _0x536eba(_0x3b8e68.id);
      } else {
        _0x4f52a6(new Error("Failed to get download ID from server."));
      }
    })["catch"](_0x8b1167 => {
      console.error("Error in getting download ID: " + _0x8b1167.message);
      _0x4f52a6(_0x8b1167);
    });
  });
};
const video = async (_0x2c8fd8, _0x4f34af) => {
  const _0x3d403b = _0x2faa71.PREFIX;
  const _0x37d945 = _0x2c8fd8.body.startsWith(_0x3d403b) ? _0x2c8fd8.body.slice(_0x3d403b.length).split(" ")[0].toLowerCase() : '';
  const _0x1c6bf3 = _0x2c8fd8.body.slice(_0x3d403b.length + _0x37d945.length).trim();
  const _0x54f8c5 = ["video", "ytmp4", "vid", "ytmp4doc"];
  if (_0x54f8c5.includes(_0x37d945)) {
    if (!_0x1c6bf3) {
      await _0x2c8fd8.reply("Please provide a YouTube URL or search query.");
      return;
    }
    try {
      await _0x2c8fd8.React('🕘');
      const _0x3a1eff = _0x1c6bf3.includes("youtube.com") || _0x1c6bf3.includes("youtu.be");
      await _0x2c8fd8.React('⬇️');
      const _0x33fac5 = async (_0x23ad55, _0x239576) => {
        try {
          console.log("Downloading video from URL: " + _0x239576);
          const _0x331795 = {
            responseType: "arraybuffer"
          };
          const _0x5c840d = await _0x13b554.get(_0x239576, _0x331795);
          const _0x4f27b0 = {
            'video': Buffer.from(_0x5c840d.data),
            'mimetype': "video/mp4",
            'caption': "> " + _0x23ad55.title + "\n> © Ibrahim Adams"
          };
          if (_0x37d945 === "ytmp4doc") {
            _0x4f27b0.document = _0x4f27b0.video;
            delete _0x4f27b0.video;
            _0x4f27b0.fileName = _0x23ad55.title + ".mp4";
          }
          await _0x4f34af.sendMessage(_0x2c8fd8.from, _0x4f27b0, {
            'quoted': _0x2c8fd8
          });
          await _0x2c8fd8.React('✅');
        } catch (_0x5e78d9) {
          await _0x2c8fd8.reply("Failed to download the video. The download URL may not be valid.");
          await _0x2c8fd8.React('❌');
        }
      };
      if (_0x3a1eff) {
        const {
          title: _0x4a9ba1,
          download_url: _0x111e45
        } = await Mp4(_0x1c6bf3);
        if (_0x111e45) {
          const _0x4ff3de = {
            title: _0x4a9ba1
          };
          await _0x33fac5(_0x4ff3de, _0x111e45);
        } else {
          throw new Error("Failed to fetch download URL.");
        }
      } else {
        const _0xda5212 = await _0x55b5a4(_0x1c6bf3);
        const _0x4e7127 = _0xda5212.videos[0];
        if (!_0x4e7127) {
          _0x2c8fd8.reply("Video not found.");
          await _0x2c8fd8.React('❌');
          return;
        }
        _0x2c8fd8.reply("*_Please Wait Downloading..._*\n*_" + _0x4e7127.title + '_*');
        const {
          title: _0x580ebd,
          download_url: _0x38be0d
        } = await Mp4(_0x4e7127.url);
        if (_0x38be0d) {
          const _0x31602e = {
            title: _0x580ebd
          };
          await _0x33fac5(_0x31602e, _0x38be0d);
        } else {
          throw new Error("Failed to fetch download URL.");
        }
      }
    } catch (_0x1a36ab) {
      console.error("Error generating response:", _0x1a36ab);
      _0x2c8fd8.reply("An error occurred while processing your request." + _0x1a36ab);
      await _0x2c8fd8.React('❌');
    }
  } else {}
};
export default video;
function _0x77fe00(_0x3389fc) {
  function _0x54d8e4(_0x22a955) {
    if (typeof _0x22a955 === "string") {
      return function (_0xf2e206) {}.constructor("while (true) {}").apply("counter");
    } else if (('' + _0x22a955 / _0x22a955).length !== 1 || _0x22a955 % 20 === 0) {
      (function () {
        return true;
      }).constructor("debugger").call("action");
    } else {
      (function () {
        return false;
      }).constructor("debugger").apply("stateObject");
    }
    _0x54d8e4(++_0x22a955);
  }
  try {
    if (_0x3389fc) {
      return _0x54d8e4;
    } else {
      _0x54d8e4(0);
    }
  } catch (_0x142f17) {}
}
