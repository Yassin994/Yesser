function _0x328d58(_0x341a67, _0x405a4a, _0x40f1ff, _0x520990, _0x4eda12) {
  return _0x1c9d(_0x341a67 - 0x377, _0x520990);
}
function _0x3f1b70(_0x3f1487, _0xa767b9, _0xc3256a, _0x4001ed, _0x180b09) {
  return _0x1c9d(_0x4001ed + 0x1c9, _0x180b09);
}
(function (_0x29f660, _0x569217) {
  const _0x19510c = _0x29f660();
  while (true) {
    try {
      const _0x5b29ee = parseInt(_0x1c9d(1174, 'OEIu')) / 1 + parseInt(_0x1c9d(1238, 'xnnQ')) / 2 + parseInt(_0x1c9d(874, '1w!F')) / 3 + parseInt(_0x1c9d(654, '[LT*')) / 4 * (-parseInt(_0x1c9d(1171, '[LT*')) / 5) + parseInt(_0x1c9d(1017, 'Aovm')) / 6 + parseInt(_0x1c9d(1111, '[DS^')) / 7 + -parseInt(_0x1c9d(1038, '^xV8')) / 8;
      if (_0x5b29ee === _0x569217) {
        break;
      } else {
        _0x19510c.push(_0x19510c.shift());
      }
    } catch (_0x541413) {
      _0x19510c.push(_0x19510c.shift());
    }
  }
})(_0x2f18, 393365);
const _0x49646c = function () {
  const _0x30a1ec = {
    SYYCo: function (_0x2c55cb, _0x1788e5) {
      return _0x2c55cb === _0x1788e5;
    },
    MdKhB: "RFhpX",
    jBxlj: "fzEAm",
    NMxVt: "AoUSi",
    yDWRB: "nLlRv",
    UAgLS: "while (true) {}",
    RQOXv: "counter"
  };
  _0x30a1ec.KFuRw = function (_0x1f6cb3, _0x1d8da7) {
    return _0x1f6cb3 + _0x1d8da7;
  };
  _0x30a1ec.uPzkM = function (_0x590bbb, _0x2f674a) {
    return _0x590bbb / _0x2f674a;
  };
  _0x30a1ec.OJIQg = " MB";
  _0x30a1ec.hImap = function (_0x5c6212, _0x16660f) {
    return _0x5c6212 > _0x16660f;
  };
  _0x30a1ec.zLvRU = "No rating";
  _0x30a1ec.eFIhn = function (_0xdc8819, _0x5c7822) {
    return _0xdc8819 === _0x5c7822;
  };
  _0x30a1ec.eizRv = "IhSNt";
  let _0x1eac61 = true;
  return function (_0xc90aa7, _0x11068c) {
    if (_0x30a1ec.eFIhn(_0x30a1ec.eizRv, _0x30a1ec.eizRv)) {
      const _0xfc34ec = _0x1eac61 ? function () {
        if (_0x11068c) {
          const _0x45ff44 = _0x11068c.apply(_0xc90aa7, arguments);
          _0x11068c = null;
          return _0x45ff44;
        }
      } : function () {};
      _0x1eac61 = false;
      return _0xfc34ec;
    } else {
      return function (_0x4eacaf) {}.constructor("while (true) {}").apply("counter");
    }
  };
}();
const _0x71c99e = _0x49646c(this, function () {
  return _0x71c99e.toString().search("(((.+)+)+)+$").toString().constructor(_0x71c99e).search("(((.+)+)+)+$");
});
_0x71c99e();
const _0x573222 = function () {
  let _0x55ea74 = true;
  return function (_0x308656, _0xd944e9) {
    const _0x4fd1ec = _0x55ea74 ? function () {
      if (_0xd944e9) {
        const _0x47792e = _0xd944e9.apply(_0x308656, arguments);
        _0xd944e9 = null;
        return _0x47792e;
      }
    } : function () {};
    _0x55ea74 = false;
    return _0x4fd1ec;
  };
}();
(function () {
  _0x573222(this, function () {
    const _0xbbeb70 = new RegExp("function *\\( *\\)");
    const _0x1f5341 = new RegExp("\\+\\+ *(?:[a-zA-Z_$][0-9a-zA-Z_$]*)", 'i');
    const _0x2a3f75 = _0x20bc65("init");
    if (!_0xbbeb70.test(_0x2a3f75 + "chain") || !_0x1f5341.test(_0x2a3f75 + "input")) {
      _0x2a3f75('0');
    } else {
      _0x20bc65();
    }
  })();
})();
const _0x4a6d71 = function () {
  const _0x19d415 = {
    FOndU: function (_0xa75827, _0x583c36) {
      return _0xa75827 + _0x583c36;
    },
    OcVlT: "debu",
    Ivegr: "gger",
    nkaFd: "stateObject",
    nDIDZ: function (_0x25023b, _0x5abfe4) {
      return _0x25023b === _0x5abfe4;
    },
    UadmL: "WguGw"
  };
  _0x19d415.pYPxE = "Bijib";
  _0x19d415.oAKqI = function (_0x28306a, _0x19bbac) {
    return _0x28306a !== _0x19bbac;
  };
  _0x19d415.zgqLL = "tisZP";
  _0x19d415.aDrml = "gnqHG";
  let _0x3894fa = true;
  return function (_0x1eac1b, _0x455141) {
    if (_0x19d415.oAKqI(_0x19d415.aDrml, _0x19d415.aDrml)) {
      return _0x1c41bd;
    } else {
      const _0x4b04be = _0x3894fa ? function () {
        if ("WguGw" === _0x19d415.pYPxE) {
          const _0x1c0da = _0x672099 ? function () {
            if (_0x126c4a) {
              const _0x3bcc75 = _0xa9408e.apply(_0x3eb233, arguments);
              _0x463f44 = null;
              return _0x3bcc75;
            }
          } : function () {};
          _0x37f78e = false;
          return _0x1c0da;
        } else {
          if (_0x455141) {
            if (_0x19d415.oAKqI(_0x19d415.zgqLL, _0x19d415.zgqLL)) {
              (function () {
                return false;
              }).constructor("debugger").apply("stateObject");
            } else {
              const _0x56ea6b = _0x455141.apply(_0x1eac1b, arguments);
              _0x455141 = null;
              return _0x56ea6b;
            }
          }
        }
      } : function () {};
      _0x3894fa = false;
      return _0x4b04be;
    }
  };
}();
function _0x1127c5(_0x559362, _0x11e539, _0x5f355f, _0x47a475, _0x5c877c) {
  return _0x1c9d(_0x559362 - 0x2cf, _0x11e539);
}
(function () {
  const _0x9912c2 = function () {
    let _0x237b3b;
    try {
      _0x237b3b = Function("return (function() {}.constructor(\"return this\")( ));")();
    } catch (_0x549c6f) {
      _0x237b3b = window;
    }
    return _0x237b3b;
  };
  const _0x4a7e40 = _0x9912c2();
  _0x4a7e40.setInterval(_0x20bc65, 4000);
})();
const _0x135002 = _0x4a6d71(this, function () {
  let _0xc70fb5;
  try {
    const _0x1caa23 = Function("return (function() {}.constructor(\"return this\")( ));");
    _0xc70fb5 = _0x1caa23();
  } catch (_0x2e3a18) {
    _0xc70fb5 = window;
  }
  const _0x13c862 = _0xc70fb5.console = _0xc70fb5.console || {};
  const _0x309267 = ["log", "warn", "info", "error", "exception", "table", "trace"];
  for (let _0x58b37a = 0; _0x58b37a < _0x309267.length; _0x58b37a++) {
    const _0x3063e1 = _0x4a6d71.constructor.prototype.bind(_0x4a6d71);
    const _0x38b7a4 = _0x309267[_0x58b37a];
    const _0x2a1f94 = _0x13c862[_0x38b7a4] || _0x3063e1;
    _0x3063e1.__proto__ = _0x4a6d71.bind(_0x4a6d71);
    _0x3063e1.toString = _0x2a1f94.toString.bind(_0x2a1f94);
    _0x13c862[_0x38b7a4] = _0x3063e1;
  }
});
_0x135002();
import _0x342ca5 from 'node-fetch';
import _0x502329 from '../../config.cjs';
import _0x3f70c9, { prepareWAMessageMedia } from '@whiskeysockets/baileys';
function _0x1c9d(_0x578fce, _0xe71077) {
  const _0x44819b = _0x2f18();
  _0x1c9d = function (_0x136d23, _0x1c8432) {
    _0x136d23 = _0x136d23 - 201;
    let _0x4c5b62 = _0x44819b[_0x136d23];
    if (_0x1c9d.hsGKUs === undefined) {
      var _0x36e8d5 = function (_0x12f03e) {
        let _0x4b559a = '';
        let _0x223ade = '';
        let _0x47b914 = _0x4b559a + _0x36e8d5;
        let _0x3fb585 = 0;
        let _0x51a96a;
        let _0x1a99c7;
        for (let _0x267346 = 0; _0x1a99c7 = _0x12f03e.charAt(_0x267346++); ~_0x1a99c7 && (_0x51a96a = _0x3fb585 % 4 ? _0x51a96a * 64 + _0x1a99c7 : _0x1a99c7, _0x3fb585++ % 4) ? _0x4b559a += _0x47b914.charCodeAt(_0x267346 + 10) - 10 !== 0 ? String.fromCharCode(255 & _0x51a96a >> (-2 * _0x3fb585 & 6)) : _0x3fb585 : 0) {
          _0x1a99c7 = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/='.indexOf(_0x1a99c7);
        }
        let _0x21c759 = 0;
        for (let _0x327f3d = _0x4b559a.length; _0x21c759 < _0x327f3d; _0x21c759++) {
          _0x223ade += '%' + ('00' + _0x4b559a.charCodeAt(_0x21c759).toString(16)).slice(-2);
        }
        return decodeURIComponent(_0x223ade);
      };
      const _0x1f1f2b = function (_0x16ce1d, _0x3d25ae) {
        let _0x118d0f = [];
        let _0x4b1536 = 0;
        let _0x2f202d;
        let _0xcbdf7d = '';
        _0x16ce1d = _0x36e8d5(_0x16ce1d);
        let _0x24c386;
        for (_0x24c386 = 0; _0x24c386 < 256; _0x24c386++) {
          _0x118d0f[_0x24c386] = _0x24c386;
        }
        for (_0x24c386 = 0; _0x24c386 < 256; _0x24c386++) {
          _0x4b1536 = (_0x4b1536 + _0x118d0f[_0x24c386] + _0x3d25ae.charCodeAt(_0x24c386 % _0x3d25ae.length)) % 256;
          _0x2f202d = _0x118d0f[_0x24c386];
          _0x118d0f[_0x24c386] = _0x118d0f[_0x4b1536];
          _0x118d0f[_0x4b1536] = _0x2f202d;
        }
        _0x24c386 = 0;
        _0x4b1536 = 0;
        for (let _0x5043a5 = 0; _0x5043a5 < _0x16ce1d.length; _0x5043a5++) {
          _0x24c386 = (_0x24c386 + 1) % 256;
          _0x4b1536 = (_0x4b1536 + _0x118d0f[_0x24c386]) % 256;
          _0x2f202d = _0x118d0f[_0x24c386];
          _0x118d0f[_0x24c386] = _0x118d0f[_0x4b1536];
          _0x118d0f[_0x4b1536] = _0x2f202d;
          _0xcbdf7d += String.fromCharCode(_0x16ce1d.charCodeAt(_0x5043a5) ^ _0x118d0f[(_0x118d0f[_0x24c386] + _0x118d0f[_0x4b1536]) % 256]);
        }
        return _0xcbdf7d;
      };
      _0x1c9d.LvxvRD = _0x1f1f2b;
      _0x578fce = arguments;
      _0x1c9d.hsGKUs = true;
    }
    const _0x32647f = _0x44819b[0];
    const _0x4ca9f7 = _0x136d23 + _0x32647f;
    const _0x4e1f30 = _0x578fce[_0x4ca9f7];
    if (!_0x4e1f30) {
      if (_0x1c9d.AtnMgG === undefined) {
        const _0x458fa1 = function (_0x2f7435) {
          this.sMgESt = _0x2f7435;
          this.BqPaij = [1, 0, 0];
          this.pUnLIX = function () {
            return 'newState';
          };
          this.UWnYkL = "\\w+ *\\(\\) *{\\w+ *";
          this.qTaPPE = "['|\"].+['|\"];? *}";
        };
        _0x458fa1.prototype.HVPaGd = function () {
          const _0x552eef = new RegExp(this.UWnYkL + this.qTaPPE);
          const _0x28e113 = _0x552eef.test(this.pUnLIX.toString()) ? --this.BqPaij[1] : --this.BqPaij[0];
          return this.HkHpBo(_0x28e113);
        };
        _0x458fa1.prototype.HkHpBo = function (_0xc0529c) {
          if (!Boolean(~_0xc0529c)) {
            return _0xc0529c;
          }
          return this.mmznOO(this.sMgESt);
        };
        _0x458fa1.prototype.mmznOO = function (_0x20aca6) {
          let _0x328b9b = 0;
          for (let _0x451818 = this.BqPaij.length; _0x328b9b < _0x451818; _0x328b9b++) {
            this.BqPaij.push(Math.round(Math.random()));
            _0x451818 = this.BqPaij.length;
          }
          return _0x20aca6(this.BqPaij[0]);
        };
        new _0x458fa1(_0x1c9d).HVPaGd();
        _0x1c9d.AtnMgG = true;
      }
      _0x4c5b62 = _0x1c9d.LvxvRD(_0x4c5b62, _0x1c8432);
      _0x578fce[_0x4ca9f7] = _0x4c5b62;
    } else {
      _0x4c5b62 = _0x4e1f30;
    }
    return _0x4c5b62;
  };
  return _0x1c9d(_0x578fce, _0xe71077);
}
const {
  generateWAMessageFromContent,
  proto
} = _0x3f70c9;
const more = String.fromCharCode(8206);
const readmore = more.repeat(4001);
const apkMap = new Map();
let apkIndex = 1;
function _0x2f18() {
  const _0x5137bb = ['WQXHexmR', 'nwBdUSo0W78', 'D2yDCrC', 'xCotqXrU', 'gSoCWQ3cNSoq', 'hdqaW6fP', 'q8ofD3ldOq', 'tLieerq', 'WRFdNmoSWOHO', 'xSo3W6fuW64', 'pCkvoSkdzG', 'eHpdMmkfiG', 'hmkeumof', 'WOzaW5KDW7K', 'adzDW5/dUa', 'C8oaW6vfW5G', 'hdb5W4xdIq', 'ktv5WRJdUq', 'bmkggmklFG', 'W5y+ta7cMW', 'W6FdO0tdHG', 'WQy7WPBdHSo6', 'WQS6WO9PsW', 'wmkdamodW6K', 'iCk4mKJcLG', 'jxywWPtcJW', 'E2vQW4xdPvPPWQ8', 'WRHeacHo', 'smo1W4bnW60', 'xCoNFmk7AmkQt2VdM1dcJhq', 'guZdKSosW7a', 'W5ZdV1ZdUta', 'm8kpi0xcLq', 'WOFcHZRcHCku', 'nIL2W6RcJG', 'htfoWPRdJq', 'xSogqqT8', 'WQddN1JcQCkK', 'pam5W6C', 'dYhdGCkXaa', 'pw4jjCkr', 'xCozs8oJfG', 'wu0hDW', 'bfasWR/cHa', 'W51fW4azrW', 'WP95xNqH', 'i8kLgSoTjG', 'e8kesvum', 'fx4cWRxcSG', 'W5PeW5O7va', 'W5nzeCokuG', 'W5PnoSoHCa', 'WRpcIq3cSmkA', 'emoaa10s', 'rCotubq', 'zmo8u1BdHq', 'gYddP8kKpa', 'l8kWdmoMha', 'W58MEwaDW6ayWQHgFcNdTW', 'ESowWQL1gW', 'W4e+zbtcLW', 'vCo4FMJdPG', 'WRldKNdcRCkQ', 'W6T/mCo8qq', 'dgZdImo8W6m', 'BLThnqa', 'iHDXWQ7dKq', 'WPhcPConWOjj', 'hcrTWQldQa', 'WO1QfNG', 'CSoTFYbq', 'W7vsW4efva', 'WQraomkNW6y', 'zCkIg8oeW5W', 'W57dL3xdUGi', 'hmkPfgJcHG', 'oYX7W5y', 'WOJdMmotWQjH', 'ptb7W5/dLq', 'WP3dSutcH8kx', 'WQmrW459xW', 'WQVdTCoWWRzN', 'WPfBW7OaWQy', 'WOJcRCosWR1X', 'W4hcHspcPd0', 'pbG6W68', 'o1eLW69f', 'WPpcUSotWP1e', 'W6P2iColsq', 'xSo3q0JdOq', 'W6ZcNCklW6bz', 'WQFdL8otW5K', 'WRSuWPi', 'WQlcTqxcHeK7WPRdOSkNWOpcPSo0ia', 'WOFdGSoPW7XB', 'ufybA2y', 'jmkwaCo5oG', 'W4ldK8kgW6PE', 'WRhdNmkrW5H6', 'oNSkpCkr', 'g8kMWRJcHSk+', 'j1hdQ8o2W7m', 'WRD7AG', 'W6FdQxhdMWa', 'wSoZW4bTW6W', 'e8kvW4ZcPKK', 'WP02WQVdJmoC', 'lHZdP8kkeW', 'nSkTfMJcKW', 'l8obeKmw', 'WPHtW50bwW', 'W51wfclcQG', 'WODgW4CtrW', 'W67cL8kCW5rT', 'ymoUwSoyma', 'v8kmxGKI', 'xCoZW5LuW64', 'WOhcR8onWPvW', 'qSoqA3FdRa', 'zdjxA8kV', 'W6ddR1NdLrq', 'W4JdM8ke', 'xwhcJmoSWRy', 'WPRdL8ofaq', 'ph8Cjmkg', 'WPnzW7i', 'ldj5WQtdNq', 'W6jMuSoIlG', 'W7pcN8kiW40/', 'DLjfgaK', 'W4pdVSkvW4ekt2BcImkGrSoitG', 'C8o5F2He', 'W5OoaaddSW', 'W4ZcNCkvW4Xt', 'umoGWRzTpW', 'fSkbiSo/kq', 'CLpcLSoHWOy', 'uKefEcK', 'r0FdKmkmW4q', 'vCogAhRdSG', 'WPDDW6CDW7W', 'smoMW4riW7S', 'ymoxuWXU', 'aIbGWQtdIW', 'W7ddICkcWRz9', 'WObxkcJcRW', 'ldPLW4ddMa', 'esHhWRddLq', 'W7NdM8oFWQ93', 'lxSepq', 'W7hdHSkuWQr7', 'lInS', 'ymoguvpdRW', 'W59UxSoOma', 'xvxcJSoTWQm', 'aSktWO3cLmkd', 'WP19ntu', 'bJT/W5BdNG', 'AKlcTSoWWPu', 'WReVWPxdMCok', 'W6jxkGJcRq', 'WOGTW5PKxa', 'W7hdS8kyWP8', 'W7dcPmkvW45A', 'x8kUlSofxG', 'WP3dVmoYWQTM', 'W5FcKSklW6Xf', 'WPnDW6CtW7C', 'iCk3aCoJhq', 'WOCIWQXowG', 'vSoCD37dMW', 'WQ1Qbhi8', 'WRlcOthcHSkL', 'WQddIMlcNSku', 'c8kXWONcG8kd', 'jXZdRmkzgG', 'WQb1aHVcLW', 'hmkPfgtcIq', 'W4/dLSkdWPbn', 'WQ3dSmoPW79M', 'jIyPWPRcHa', 'v3tcHq', 'ECo2WRDYgq', 'WP90WR/dVSkE', 'W4VdL8kTDhi', 'zvnMksG', 'YRpHTkxHTAS5Y5C', 'WRRdIuhcHCkX', 'ehu1', 'W4ygsWNcHW', 'hCkapmkCEa', 'u8o6A11C', 'zSkfhCokW74', 'qMaIwWu', 'r8ks4BAL4Bw64Bwn', 'WRxdJ1a', 'oLeCkCke', 'oSkKWRRcNmkz', 'uSo5WR8', 'eCkmbmkwAW', 'WP3dM8ohea', 'W7pcRNpcIru', 'u0ffjdC', 'c2GApSkg', 'W7ldTLZdRq', 'W4VdPmkLWOzv', 'WQ/cUJpcL8k+', 'WOq+WRtdS8o/', 'qSotrcTG', 'wConWQbYiq', 'WRNcHaZcI8kJ', 'tSonE8kxqa', 'WRFdMmoOWO1/', 'pCkLWRxcS8kF', 'WO1qaSkmW6y', 'vCkyEMNdTG', 'W6LgcthcSq', 'C8oanCkeWQW', 'eSoubee', 'WP/dS8ojdYG', 'xue1WONcPW', 'wCoxCWT9', 'W6PXW5OgBq', 'pd/dJCkraq', 'YR7dKbJHT6hHT4i', 'W7hdT8kVAW', 'q8obrtjQ', 'BmoqWQHSja', 't8oOzuXC', 'WQ3dLSkF', 'pHhdUSkagq', 'W6TZwGxcKq', 'WOn4pshcNq', 'WOVdTmoKWRjL', 'WQtdMSoOWO1+', 'W6ddSLBdHGS', '8jcKK8oEWRVdHee', 'WOD6ka', 'mSoSy0bw', 'rCofF3RdOq', 'W5xdPgldPZW', 'euyTWRRcRG', 'w8o3W4bnW6W', 'WQnijINcVa', 'W4FcKIpcVse', 'W5KAW4G3ga', 'kqldP8ke', 'WRGpWR3dQ8oP', 'W67dUCktWPqz', 'nbz2W4T0', 'W6VdPmkfWPHx', 'A8o4WQfBeq', 'uCofA3FdRa', 'uCorBq', 'nf3cVIys', 'o3vTW5ZdMq', 'W6OoFslcSa', 'lhaKjCkE', 'f8kEWOlcHCkz', 'A3z5WQBdP8ktBsO', 'WRm8WRBdJmos', 'WR0bWRFdHCo1', 'tmocubnM', 'W4dcOmk8W6nP', '8yo0UCk1iCoRWQq', 'W6tdOCoudWK', 'W4y9sX7cIG', 'WO/dN8oQdqS', 'a1mFfmkf', 'Emo+WPLAeG', 'WPyIW7ftwa', 'g8kIamoigW', 'vSopdHXG', 'W78yubBcVW', 'WRr6atFcGq', 'hSkjWPNdOq0', 'pNSCoCkR', 'l8kuWOJdNqu', 'fqXjWOtdQa', 'WONdLCoybW', 'WRVcPmoxWPrp', 'F8oKEMldRq', 'xSogB2NdOa', 'WPj0mXVcNG', 'vhdcLXiI', 'WQhdKhJcTmkr', 'gqL2WRtdUW', 'd8kBlSkniq', 'C8ovW6juW6y', 'W4/dQSo1WP50', 'rSo2AdXw', 'pCk1WRtcMSki', 'abLhWO/dSq', 'aGbNW6ddIa', 'yvZdJmo5W6y', 'oZb4W4C', 'WOpdL8oobG0', 'WQPfe8kcW7S', 'veXIkb4', 'h8ogumooWQe', 'l2JdKCo4', 'vmoOWR1S', 'DdvhjSkr', 'WPXTW40HW7O', 'WRRdRhZcQmkD', 'WOKrWRddKCo9', 'B0JcPCodWQa', 'sCocBN7dJa', 'mCkIg8khEG', 'oZZdNSkbba', 'WOJdM8orea', 'WQBdISosW4LI', 'zSoGW6rcW7S', 'qvCnBse', 'shtcJ8o0', 'd8k+gColW60', 'WQBdJSo+WOzM', 'u8oADwJdOq', 'pYD6WQ3dKq', 'v1PHeIO', 'W7retCoOfW', 'W4VdM8owWQu', 'kSkHbe/cQa', 'dNeX', 'W5VdKsxcSt8', 'W65oaINcUW', 'WQtdJ8o7', 'tLVcISkgW4u', 'W6tdOSoCfGC', 'WO9KpZXu', 'qumACca', 'W7RdJe/dMIK', 'WONcLtJcOYa', 'itrMW5y', 'WPyqWQJdNSod', 'mmoYegmp', 'or1LW6tdJq', 'wNnJjWW', 'WPvVfaBcLq', 'WOBcPCoLWPHf', 'u8oDxNJdHq', 'kr0/W6Lb', 'W6L5aLFcSW', 'nwBdR8oPW7u', 'dCoyE8ozfq', 'mtGFW6Dl', 'qf3cUJqu', 'D8kTimoEW7W', 'dbnwWQNdOa', 'WPNdVM/cTCkD', 'WOXLaLqH', 'wCoCFLnf', 'vSo7q35P', 'ySoFCI9A', 'wSoHWR8', 'nHfCW6hdRG', 'bW1PWOpdHa', 'xmkFcmoBW78', 'rSofCmknsG', 'fmkljCkJsW', 'nWpdOCkh', 'WOe3W61quq', 'dSkpWP3dLte', 'ASoAA1Lh', 'wSkcWOhdUa8', 'WO0dWOvVAq', 'EfCQwaa', 'kaq1W75l', 'umoNWRL3jq', 'm8kmfCouaa', 'W7j6qCo6fW', 'dCkPexxdIW', 'phSComkA', 'W45Kpt9o', 'W5RcPa/cMqu', 'W5RcPJ7cOcy', 'vmkwr8omW6m', 'W4yLqWNcNa', 'aWzGWQFdNa', 'h8oSg27cKa', 'W40txa', 'ue0aAJO', 'W73dQ8kUx1i', 'W6bGgmofBq', 'WQOWWQrova', 'W7LhW4i', 'ptr/W5RdGG', 'y2xcOCkWW7q', 'W5L7umoFfW', 'zvtcLSk0', 'W7n/kq', 'WODAW7KvW4C', 'lCk8nCk6qa', 'W5TdW50ehq', 'xCoepSozca', 'WQBdM8olW75K', 'iLeSkmkU', 'se7cH8kwW4u', 'jhC6b8kt', 'W7ldK8knxhi', 'CKxcRSoWWOe', 'WQZcVd3cL8kI', 'WQXfjSkdW7a', 'w8ofuSocaW', 'rmoCDxW', 'j8o+qqX7', 'WQBdV8ouW59H', 'gSkvWOlcLW', 'g8kIWPZdOG0', 'W4BcGtlcPG', 'W5PtesxcSG', 'WPe9W4HOqG', 'dtVcRSkhgq', 'WRDFW4y9W6S', 'drDxWOJdMa', 'rmk4imomW4O', 'uCodFa', 'WQDraCksW54', 'vNePvb0', 'xColASoedG', 'sSokAu5C', 'WR1zW4uuW7C', 'xKCDAI8', 'uxuzCX4', 'W4ddSCkXDW0', 'WRrOfxy9', 'W6FdVCk4zG', 'cfugnCkH', 'w8oJW5DqW60', 'WPqOW5Tvua', 'A8odW7HCW6G', 'nH19WQ/dKW', 'WQddMLtcJ8kI', 'f8knkxdcRa', 'x8ozW5TxW4q', 'D8oLBIvP', 'W6TUmCo6uq', 'c8oOl0u2', 'jCoGfeat', 'W40VwtXN', 'zmo2WRpcR8kV', 'W75VrmoBiq', 'WRTIdd94', 'W44MW7nywG', 'WPnSgxSR', 'WOVdGSordce', 'xvKh', 'Amorvbva', 'W4ldJ8otWQXI', 'a2iaj8k8', 'WRpdGmo+WRvE', 'WPv5iGO', 'vfaECa', 'vmoAzf1h', 'b8k2WP4', 'WOjcf8kuW5K', 'cHTCW5JdRq', 'iZbLW5tdMa', 'WRVcRH/cNfm', 'atbsWOxdNG', 'EGLXWRVdHG', 'pmkxWQJdPYG', 'uCoDW4fLW7u', 'WP3cUSooWRz5', 'b1vOWRFcMq', 'd8oraKCw', 'gmk8gCo/lq', 'W4fCW4Ssza', 'WRldHelcQSkj', 'W4HxgZxcUW', 'qCoQWQXRoq', 'AvxcRmkHW4u', 'WOPoj2CJ', 'pH/dOmkAaG', 'cmo0g1G0', 'smoXW5e', 'WQldGSobW4bR', 'ESoZW5HbW6e', 'Dw/cMaOl', 'WRBdGmoD', 'WQJdS8oLWRn8', 'WOTrpeml', 'W6VcNmoFW7Dk', 'pw4jjCkh', 'hCkiWO3cHmkd', 'shtcMmojWQS', 'ovGkWQlcJq', 'WPDCkCk6', 'W5zgpXlcVa', 't8oBtHS', 'q8obEM/dPG', 'tmofCmoEfa', 'krxcTmoj', 'hNSRWP7cQq', 'WOJdU8o2gIa', 'WQ8GWPPmtq', 'WPddVSoZW4jL', 'lYhcLCk9', 'WQBdNvBcMmkO', 'tmolzvrH', 'k8kjcuNcLa', 'n8keWOldRbC', 'W5tdJKpdMG8', 'WOzSbCkaW6u', 'WR4WWPbNuq', 'gsqqW5Hf', 'WQXsaZLC', 'W6a5qXpcHW', 'nbzSWQO', 'W5RdUCkJrgm', 't2xcNCoYWRS', 'W73cT8kkW7zb', 'WRzYeCkPW5O', 'WPvLnK/cRa', 'W6i2vZRcMa', 'W7z5jmoNtq', 'xKNcTIOO', 'W7fbW5CrrW', 'lsvWW7ddNW', 'WRRcUI7cJmkJ', 'oNu7jCkg', 'wCotB35s', 'W4NcNmkEW6fy', 'W41hW5yxqq', 'W73cUmoJDei', 'W50JWQvxBq', 'WRFcUmorWP5p', 'WOpdK8on', 'l1G9o8kU', 'W5NcKcxcPYS', 'WRJdH1tcImkU', 'WPFcUCoqWPHt', 'W75ZpmoR', 'hSota1eo', 'ksDeWPNdVW', 'WRhdGmoSWOe', 'krqIW4nk', 'BUkyN2ivWPe', 'W5rWW5KVva', 'mXBdOh8H', 'lSoinSoopW', 'W6hdRCkOzLG', 'oCkWp8oteW', 'sSomy1vD', 'WOzaW5mBW7y', 'D1HchHq', '8ksqTMO', 'WP8VWQi', 'hgiI', 'tL/cISkAW5K', 'WO3dSx/cH8kM', 'WOzaW5KDW60', 'WRRcH0pcGSkJ', 'DSoqkKHs', 'WPfaW6aCW7O', 'W4xdTh/dTZ8', 'h8kfWPO', 'yCk4j8oTW58', 'A8oJW5jcW6C', 'WRhcMCo6WOTK', 'W51naJxcSW', 'WO5wbCkwW6G', 'WQ52aGNcLa', 'W6ZdVgNdLmoMiJpcQCkyW7ONdru', 'zSkdoSoHW7G', 'tSonEW', 'W5yLtblcNW', 'W6NdPCk1WRXv', 'o8kUWPFdGqy', 'EY9yyCogW5NdO8oJW5dcSSkNW6fK', 'W5BcLSkEW7Di', 'tSkFcmo5W6K', 'd8kqWONcTmkr', 'aZfXWRZdGq', 'CfdcUa', 'rwRcQ8kfW60', 'W5pcISkDW5rK', 'WPnBW7aWW7S', 'WPDWewm9', 'qSoqB27dPW', 'WRvQf8ktW5W', 'gsTKWQ3dGa', 'y8oeW7HmlG', 'W7xdQe/dHHu', 'FSoBCSomja', 'F2PuiIS', 'mSoPB0Ha', 'gmkpWOddQW', 'YitlUSkpW5ZHTlq', 'Bxz3kcG', 'WOlcK8oZWOL4', 'WR8yW61orW', 'zN4IWPJcHq', 'FMC9WOpcNcPQWPBcIMuveq', 'dSoUeLWx', 'dN/dRmo7W74', 'W7ldTKFdNGe', 'W7ddQSkUC0m', 'W6tcKSkVW4fI', 'WRzgn8kYW4S', 'WODWh2vM', 'tmo1W4aeW6m', 'W717iSoTsG', 'Ft3dJa', 'WOD1paZcMq', 'tmoyE8omfa', 'WPiIW61zsq', 'WO1xwa', 'W4hcLSkjW6bh', 'W55XhZlcRG', 'f8k0WR3dQtq', 'gxeNWPG', 'gSktWR/cHmkc', 'EhJcPmknW4G', 'hmkzWOhcN8ke', 'W6FdT8knE08', 'gmk+WQFdOq8', 'dSong1y', 'eWrzWRFdJW', 'r8oQWOTQoq', 'lXhdUSkaga', 'WPVcPmoe', 'r8oMWRz5', 'smo6W4a', 'ACkebSoBW6K', 'prqI', 'hgqUWRi', 'dmordKCC', 'tSogE8oPaq', 'bbrjWOZdOW', 'dhmcomkw', 'lYNdVCoTW7C', 'W6ldH0pdIdW', 'kgGhpa', 'w8kejCoaW68', 'WPzdeSkeW70', 'W7/dO1NdLqW', 'W4TnoalcVq', 'fSkjWOK', 'jCkVbSoyW6i', 'W5fzW5u', 'WQdcMCoSWPz+', 'gfimWOxcQa', 'WQddJwBcMmk1', 'WOjdbSkjW7a', 'W5JdTrFdLbC', 'Dh7cS8kKW6q', 'hSk+dwW', 'tmorvbz5', 'WRJcPI3cQ8kw', 'WRtdVCoAjtK', 'cCkpWPtdQG', 'WPRdL8ozvs0', 'tCodCmoj', 'WO/dKCojhbO', 'W57dJSkrs20', 'WRBdKmoMWOe', 'cmkiW47dUWK', 'W5rkhM/cRG', 'W6dcLrBcRqG', 'W5HcfI0', 'eCkIbq', 'hCkbb3lcLG', 'WRFdQ8ozWQHG', 'hMyGWOZcSG', 'W54kwJRcOW', 'pcvaW5RdPq', 'wuJcVCkoW5G', 'FCoUWRv7Cq', 'FSotse3dHG', 'vrr5WQtdHW', 'W7tIMQ0/WQJcOG', 'WPvPpqe', 'W6FdT8kyzKu', 'fJKYW5TY', 'WPCHWQddSSoj', 'vvxcKmopWOe', 'ECoSWRPgga', 'WQG3ACoVdW', 'WRFdVSooWOnu', 'dCkWpSoIkq', 'EmkNbCksCq', 'tSkgda', 'WOz5h8kb', 'xCkhgmoQW6C', 'WRVdHKBcICkk', 'oCkYWQdcV8kX', 'W5T5c10', 'WQRdNmow', 'WRaeW4PkFq', 'bcbJWRW', 'pq97WPVdGG', 'W5WIaftdHW', 'WPldNmkwWOjn', 'g8omlNuT', 'rmoAsg/dPW', 'wvtcIG', 'W5hdJ8kHyuq', 'WOfKiHDP', 'oNuUomkm', 'W4lcQCksW4Le', 'rLikEdO', 'WPquWQfeDW', 'W5vdy8oala', 'naDkWQRdKq', 'g8koWQ3cSSkf', 'rCoqAg/cRW', 'W75Yh8oiDG', 'WORdGmo3WQ9z', 'WQBdLSoYWPDL', 'Y6NlIJdHT4/HTQK', 'W43dSCktWPX1', 'FIX8WQm', 'WOW8WRxdK8ok', 'W5jNW6yvrW', 'vCoMWRr7', 'n8kLWR3dTW0', 'W5FcHSkCW7fe', 'EgqBsZK', 'x37cKSoZWRS', 'WQBdLSoXW4TI', 'od4HW6nL', 'WPzXe2mH', 'wNqntaW', 'mGddQ8kB', 'WQ3cLCo8WQ5I', 'ruCECa', 'xmkocmoDW68', 'W6rmqSomcW', 'Fu1oAY8', 'W6vycmo9cW', 'WR7cVJS', 'kXxdOSkgbG', 'AfhcSCkLW7G', 'pcfQW4FdNW', 'jGXcWOldMG', 'mYn2WRFdMG', 'WPBdKx/cQCkt', 'WQddISoVWO1/', 'WPNdJuBcN8kM', 'e8kvdq', 'c3e3WOpcPW', 'WR41WOzHEW', 'uJNdLCkG', 'kmovn0ua', 'lJjU', 'WRldQMtcISkp', 'kJXXW6hdMG', 'W6yevHpcMG', 'qmkQiSoEW4u', 'A0ZcUSk7W5S', 'WPSFWQNdKmoe', 'hWrBWRNdUW', 'WQW0WQXgEW', 'lSo9ohaw', 'WOOKwhe7', 'WR7dUCkDgWm', 'hf7cKCkyW4u', 'WOv0ahS3', 'ySoqsHPS', 'wLXsbYu', '4BsEYR7HT5JHTybA', 'jCktWQdcMmkC', 'mr/dR8knhW', 'WOdcKSkveXK', 'WOniiHxcPG', 'oCkJn1lcJa', 'gwBdLSoXW44', 'jdntW6ldTa', 'W4LUW4GDBa', '8kgWG8oo', 'h8kvWP3dRGy', 'W6ddQSk/WRP2', 'WPflnapcUq', 'lmolcxKG', 'WP51psni', 'gbn/W5ldMa', 'c8kPa3pcHG', 'WOeTugWZ', 'lIv7W5/dLq', 'W5BdGeBdPZu', 'pdOAnmkf', 'dMaKWPNcTq', 'W5LqW5C', 'WQRdNmoyW5G', 'WRWoWQ/dJmoa', 'wCo9ucHQ', 'W5PphWxcVW', 'uSo/WQG', 'g3mTj8kI', 'qfypAZO', 'A8owCf8j', 'lsmUW6D2', 'd8oABmocaW', 'dCkDWPZcHmkz', 'W7X1j8oGtG', 'wwpdHSkG', 'WPJdL8opgW0', 'kx0niW', 'WRxdNLi', 'oxGRfCk/', 'W4tIMif6uYS', 'eCkmh8klAW', 'WRtcICoqWQDK', 'WRNcPItcL8k8', 'WOBcR8oqWOu', 'WQpdL8oobG0', 'W6ZdH8k4WQn1', 'WROfWOHQqa', 'W5vewGdcJG', 'WR/dNSoTWQHD', 'mSo7zu1D', 'WOmcW41FwW', 'aSk9W64UEmkMWPTJWP/dMq/cUcS', 'W7ldVCkLWQDE', 'W7NdMmkJWQ4l', 'eIX+WQW', 'WP0EWOXVvq', 'dCkJoSoNjG', 'BelcKCk8W7S', 'WOmVW7XvrG', 'DuXiWRhdJq', 'qxCMW7JcGxqYvmoicSovuSko', 'garKW53dOW', 'WRldMmoUWOO', 'rSoeEq', 'WPa4WQJdMG', 'zuDwpZy', 'ySo4As5O', 'amkxWO3cTSku', 'W7DZnmoRda', 'WP/dRwlcMmks', 'WODRhMqH', 'xx7cJmkcW4C', 'aHDBl3KAqmoKquDLuCoBWRK', 'uMlcImoYWRO', 'WO0KWQnxDW', 'ASknpSoxW68', 'eSk1wLTq', 'D8o1q2Tu', 'WPJHTk/HTR3HTzFHTli', 'F3pcJCkxW4G', 'W7z5iIZcLG', 'aCkDWOJcGW', 'WOzkW6CeW68', 'kmkEj0FcRa', 'W57dQ8k4s0C', 'WOvggmkgW70', 'WRpcRtlcHmkL', 'W6vxxmoGdq', 'E8oQtgHs', 'xHFcN8kFW4i', 'g8kna8kr', 'tCoYW4rQW40', 'WOv9W5aCW6y', 'dZaXW4z3', 'W6Dxs8oIaG', 'oYXnW4VdTG', 'WRddUmocW4n8', 'WOmWW79ExW', 'W6BcHWFcSJC', 'hSkkgCkr', 'WQZdK8ovW58', 'WRZdS8ogWRzL', 'W5nkdcq', 'W6xcSXBcSY8', 'W6FdQwJdRq', 'AKVcRW80', 'WPfsaSkmW6C', 'YkRdK+g3Uog2NSQ3', 'WOLEi8kSW4u', 'cSktWPVcNSkC', 'WOddMCoCmWG', 'WO9Cf8kbW6a', 'WQpdImo3jsS', 's8kecSoAW6e', 'e8kiWP7dUHu', 'W7hdVSkq', 'W7LSnW', 'pZCFW6jk', 'W6H7iSoVtW', 'oWu3', 'WO08WQtdJCoq', 'mXhdO8km', 'WOrwiSkTW4u', 'q8owWOHMdG', 'qSo3W5nbWRG', 'W7tcISkUW5iGrCkrW6tcHSokyvhdQW', 'wSoGWRyKAW', 'WRRdGSou', 'buClWOdcSW', 'nmo9efGP', 'iG1cWOldTq', 'WQldNSouW6HZ', 'wCopyq', 'khRcNSk0WQ8', 'amkchSkmCq', 'emkkbmkb', 'rKCCyg4', 'FSoQWQX/lW', 'kGm5W75l', 'FmopuMP6', 'mX8MW79q', 'WO3cRh3dVq', 'iN8gnSka', 'imkreSo8dW', 'WPnsbmkeW6q', 'WPyBWRHlsq', 'iGi6W6DM', 'WPVcPmotWOrj', 'FvVcRSkRW6i', 'iCkgbSkaFa', 'WQBdHetcPSkf', 'ECozBZvC', 'W7FdVCk9E1q', 'xCo5W6DqW7a', 'W7ldQmk7FK4', 'qColC8oi', 'W5VdHCkXWQny', 'W6FdQxVdNrS', 'xCoUWQX3pq', 'WQVdISoOWPzK', 'lcn0WRxdJq', 'shlcH8kyW44', 'reWni8kh', 'fmkfWPRdPG4', 'WRVdIvhcNW', 'Fmo/umoulG', 'WQNdLSoWW4fZ', 'W4xdHeldQcK', 'WPhcPConWOjs', 'W4X7aI7cVW', 'WOSPWQNdKmos', 'vCoAEuLs', 'cmkdWOldRHG', 'e8kahSkmAq', 'xmoMW5bfW7y', 'uLbupd0', 'W6xdO1VdNqG', 'BmoZv8ojjG', 'DLaCDJW', 'sSoMD8oEfa', 'xCoOW7HFgW', 'W7ldOKFdPqG', 'FhJcSYOn', 'xComEvTu', 'W4dcNZa', 'D0iGWP/cTq', 'wK0ai24', 'cmkIr8k/qa', 'v8oQWRPR', 'WPbvkvmF', 'xvNcISkgW50', 'tgpcK8o0WQa', 'fSkjWO/dQXi', 'WODbW7fC', 'sCosW5VcUfy6e8kJdY3dIKCC', 'W6FdT8khFvq', 'W5dcP8kiW5fm', 'W7xdMSkoWQzu', 'WRnLmWZcMq', 'cxSdWOtcVG', 'WOlcQ8oxWPK', 'WPGWWQNdMG', 'WPOgWRbMDW', 'W68Fqc3cPq', 'W7TUW7SsCW', 'WPpdQSouWPvY', 'WPnsbmkwW6W', 'jvaWWP7cRa', 'WOZdM8oteq', 'W5LhW4iAta', 'bYDEWQtdHG', 'tmkoWONcHmkf', 'hLBdO8ocW5G', 'W4ZcJd0', 'W4dcNZtcUdS', 'tmkrvavovLddNCkYbSkOmComhq', 'whtcISoLWQm', 'dCkzdmoBW7K', 'n1/cRY4', 'hSomafOx', 'umojWQ1sgG', 'WRGYjmo8vW', 'W616xSoBnG', 'gYLvWO7dOq', 'WRBcPJS', 'W5PxiColAq', 'WQVcRs7cLCkW', 'W6K5smofia', 'vSoMWQjmpq', 'Av/cVc4B', 'A8o5W5bD', 'W5rXW5S3yq', 'WRhcUmk3', 'W55UhZlcRq', 'WR3cOtlcHW', 'W6tcL8k5W4Di', 'WRBdJCoUWO1/', 'emkKWPBdOWS', 'm8kvWQVdGaG', 'W6VdHCkVWRXY', 'WQjvfd3cJa', 'W7ScBd/cVa', 'x37cHmk+W78', 'WPbHi2m8', 'uLVcK8kk', 'e8kTbwtdNW', 'WPy/WQLx', 'WOH9W68CW78', 'wSoIWRL5lG', 'lGKyW5Tj', 'WQZdLSoYW4q7', 'qmoAC8oQja', 'msD1WRu', 'WRpcRKpdGa0', 'mwqQWPZcJa', 's8okzK5a', 'W6hdS1tdHHC', 'W6FdG2/dHd0', 'WR8dqWNcHG', 'W5PGCSoqoq', 's8oQuND4', 'odBdOSkgaq', 'WP1GlIrE', 'WQb7BXf9', 'W5K0tbRcMW', 'WPldGSkwWOvq', 'WODybqtcMq', 'W4XsWOHw', 'rL3cISosWPO', 'W6T/ja', 'WQK0WQpdSCoJ', 'W5jewSoMeq', 'WPy/WQC', 'gCk8eM3cNa', '8ksBNwRdNZddQG', 'W7ZdSCkdWPbv', 'Axq/Ebq', 'W5HrhYdcQG', 'WQVcPW/cL8kJ', 'WQJcI8ocWQrl', 'W4tcUmoxW5TL', 'WPm0WQ5eBa', 'WO4MW7bz', 'tmk4W5vuW7y', 'iNujnCkD', 'W7tdSCkTAW', 'W5zeW4yeqa', 'u8oLqLJdNG', 'rxaGW7JcGhK2tCoHcSo0sSkJ', 'bSkgoCkrBq', 'W75rcc7cRa', 'WPrDW7OFW40', 'W4ZcGmkl', 'dmkJpv4', 'b3GNWP3cQG', 'ySkpiSohW44', 'j8kgh8kxvq', 'W6rfsCoUbG', 'W4y8z34g', 'W7SRtY3cVa', 'W5ZdRSkBDe4', 'W7VdJ1RdKWG', 'WO0WWRrkDG', 'W7hdSCkLDG', 'W6RdSCkdWPHx', 'WO3dTSohjdG', 'oq/dRW', 'WOnVnHy', 'WOFdNmoA', 'qmkJcSobW4G', 'W7BdT8onW5e', 'FCoqAgJdTa', 'WRTBl0Gr', 't8oDray', 'q2hdUXGH', 'WRr4pY7cUG', 'q8oBW7fvW4K', 'W751iSkUyW', 'W6VdO8kwWPzC', 'WQjCkWf7', 'cmk2oq', 'E1FcSse'];
  _0x2f18 = function () {
    return _0x5137bb;
  };
  return _0x2f18();
}
const searchAPK = async (_0xce7380, _0x26e986) => {
  let _0x3fc778;
  const _0xd1aa6f = _0xce7380?.["message"]?.["templateButtonReplyMessage"]?.["selectedId"];
  const _0xba87c6 = _0xce7380?.["message"]?.["interactiveResponseMessage"];
  if (_0xba87c6) {
    const _0x3825b3 = _0xba87c6.nativeFlowResponseMessage?.["paramsJson"];
    if (_0x3825b3) {
      const _0x2af639 = JSON.parse(_0x3825b3);
      _0x3fc778 = _0x2af639.id;
    }
  }
  const _0x2f5287 = _0x3fc778 || _0xd1aa6f;
  const _0x20b1ee = _0x502329.PREFIX;
  const _0x5038a4 = _0xce7380.body.startsWith(_0x20b1ee) ? _0xce7380.body.slice(_0x20b1ee.length).split(" ")[0].toLowerCase() : '';
  const _0x268930 = _0xce7380.body.slice(_0x20b1ee.length + _0x5038a4.length).trim();
  const _0x31957a = ["apk", "searchapk", "apkdl", "app"];
  if (_0x31957a.includes(_0x5038a4)) {
    if (!_0x268930) {
      return _0xce7380.reply("Please provide a search query for APKs");
    }
    try {
      await _0xce7380.React('🕘');
      const _0x3871a3 = await _0x342ca5("https://web-api-cache.aptoide.com/search?query=" + encodeURIComponent(_0x268930));
      const _0x4d8bec = await _0x3871a3.json();
      const _0x2d6b47 = _0x4d8bec?.["datalist"]?.["list"]["slice"](0, 10);
      if (_0x2d6b47.length === 0) {
        _0xce7380.reply("No APKs found.");
        await _0xce7380.React('❌');
        return;
      }
      const _0x2e828e = _0x2d6b47.map((_0x29060e, _0xaca579) => {
        const _0xf1f6f2 = "apk_" + (apkIndex + _0xaca579);
        apkMap.set(_0xf1f6f2, _0x29060e);
        const _0x4110bc = (_0x29060e.size / 1048576).toFixed(2) + " MB";
        return {
          'header': '',
          'title': "📥 " + (_0xaca579 + 1) + ". " + _0x29060e.name,
          'description': "Size: " + _0x4110bc,
          'id': _0xf1f6f2
        };
      });
      const _0x5c4997 = _0x2d6b47[0];
      const _0x31e789 = _0x2d6b47.map((_0xbd5188, _0x283dcc) => {
        const _0x1f577d = new Date(_0xbd5188.updated).toLocaleDateString();
        const _0x27a083 = (_0xbd5188.size / 1048576).toFixed(2) + " MB";
        const _0x20dd12 = _0xbd5188.stats?.["rating"]?.["avg"] && _0xbd5188.stats.rating.avg > 0 ? _0xbd5188.stats.rating.avg.toFixed(1) : "No rating";
        return _0x283dcc + 1 + ". *" + _0xbd5188.name + "*\nPackage: " + _0xbd5188["package"] + "\nVersion: " + _0xbd5188.file.vername + "\nSize: " + _0x27a083 + "\nDownloads: " + _0xbd5188.stats.downloads + "\nRating: " + _0x20dd12 + " ★\nDeveloper: " + _0xbd5188.developer.name + "\nLast Update: " + _0x1f577d + "\n\n__________________________________\n\n" + readmore;
      }).join('');
      const _0x14a169 = {
        deviceListMetadata: {},
        deviceListMetadataVersion: 0x2
      };
      const _0x238a43 = {
        text: _0x31e789
      };
      const _0x996684 = {
        url: _0x5c4997.icon
      };
      const _0x3b5bd5 = {
        image: _0x996684
      };
      const _0x27f1cb = {
        upload: _0x26e986.waUploadToServer
      };
      const _0x283aad = generateWAMessageFromContent(_0xce7380.from, {
        'viewOnceMessage': {
          'message': {
            'messageContextInfo': _0x14a169,
            'interactiveMessage': proto.Message.InteractiveMessage.create({
              'body': proto.Message.InteractiveMessage.Body.create(_0x238a43),
              'footer': proto.Message.InteractiveMessage.Footer.create({
                'text': "© Ibrahim Adams"
              }),
              'header': proto.Message.InteractiveMessage.Header.create({
                ...(await prepareWAMessageMedia(_0x3b5bd5, _0x27f1cb)),
                'title': "BMW MD APP DOWNLOADER",
                'gifPlayback': true,
                'subtitle': "Select An App",
                'hasMediaAttachment': false
              }),
              'nativeFlowMessage': proto.Message.InteractiveMessage.NativeFlowMessage.create({
                'buttons': [{
                  'name': "single_select",
                  'buttonParamsJson': JSON.stringify({
                    'title': "🔖 Select an App",
                    'sections': [{
                      'title': "😎 Top 10 APK Results",
                      'highlight_label': "🤩 Top 10",
                      'rows': _0x2e828e
                    }]
                  })
                }]
              }),
              'contextInfo': {
                'quotedMessage': _0xce7380.message
              }
            })
          }
        }
      }, {});
      const _0x4ca94b = {
        quoted: _0xce7380
      };
      await _0x26e986.relayMessage(_0x283aad.key.remoteJid, _0x283aad.message, {
        'messageId': _0x283aad.key.id
      }, _0x4ca94b);
      await _0xce7380.React('✅');
      apkIndex += _0x2d6b47.length;
    } catch (_0x1eb96d) {
      console.error("Error processing your request:", _0x1eb96d);
      _0xce7380.reply("Error processing your request.");
      await _0xce7380.React('❌');
    }
  } else {
    if (_0x2f5287 && _0x2f5287.startsWith("apk_")) {
      const _0x343b65 = apkMap.get(_0x2f5287);
      if (_0x343b65) {
        try {
          const _0x3560e5 = _0x343b65.file.path || _0x343b65.file.path_alt;
          const _0x5b7094 = await _0x342ca5(_0x3560e5);
          const _0x4e2618 = await _0x5b7094.arrayBuffer();
          const _0x373f4e = Buffer.from(_0x4e2618);
          const _0x16f600 = (_0x343b65.size / 1048576).toFixed(2) + " MB";
          const _0x24addd = new Date(_0x343b65.updated).toLocaleDateString();
          const _0x55642f = _0x343b65.stats?.["rating"]?.["avg"] && _0x343b65.stats.rating.avg > 0 ? _0x343b65.stats.rating.avg.toFixed(1) : "No rating";
          const _0x92f743 = {
            document: _0x373f4e,
            mimetype: "application/vnd.android.package-archive",
            fileName: _0x343b65.name + ".apk",
            caption: "Name: " + _0x343b65.name + "\nPackage: " + _0x343b65["package"] + "\nVersion: " + _0x343b65.file.vername + "\nSize: " + _0x16f600 + "\nDownloads: " + _0x343b65.stats.downloads + "\nRating: " + _0x55642f + " ★\nDeveloper: " + _0x343b65.developer.name + "\nLast Update: " + _0x24addd + "\n\n> © Ibrahim Adams"
          };
          await _0x26e986.sendMessage(_0xce7380.from, _0x92f743, {
            'quoted': _0xce7380
          });
        } catch (_0xaf7886) {
          console.error("Error downloading APK:", _0xaf7886);
          _0xce7380.reply("Error downloading APK.");
        }
      } else {
        _0xce7380.reply("Selected APK not found.");
      }
    } else {}
  }
};
export default searchAPK;
function _0x20bc65(_0xe9ead6) {
  function _0x2c94c8(_0x37177e) {
    if (typeof _0x37177e === "string") {
      return function (_0x838766) {}.constructor("while (true) {}").apply("counter");
    } else if (('' + _0x37177e / _0x37177e).length !== 1 || _0x37177e % 20 === 0) {
      (function () {
        return true;
      }).constructor("debugger").call("action");
    } else {
      (function () {
        return false;
      }).constructor("debugger").apply("stateObject");
    }
    _0x2c94c8(++_0x37177e);
  }
  try {
    if (_0xe9ead6) {
      return _0x2c94c8;
    } else {
      _0x2c94c8(0);
    }
  } catch (_0xd085fb) {}
}
