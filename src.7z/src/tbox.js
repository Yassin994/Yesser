function _0x188910(_0xe08cfa, _0x517f50, _0x34f706, _0x105bc9, _0x2d972d) {
  return _0xbfa3(_0xe08cfa + 0x1de, _0x517f50);
}
(function (_0x357eef, _0x52edc0) {
  const _0x307e3d = _0x357eef();
  while (true) {
    try {
      const _0x122de9 = -parseInt(_0xbfa3(763, 'c965')) / 1 * (-parseInt(_0xbfa3(565, '!n8Q')) / 2) + parseInt(_0xbfa3(833, '(y4K')) / 3 * (-parseInt(_0xbfa3(979, '1IE4')) / 4) + -parseInt(_0xbfa3(570, 'ZvWg')) / 5 + -parseInt(_0xbfa3(933, 'VqtD')) / 6 + parseInt(_0xbfa3(835, '(y4K')) / 7 * (parseInt(_0xbfa3(544, 'NT31')) / 8) + parseInt(_0xbfa3(759, '1IE4')) / 9 * (-parseInt(_0xbfa3(744, '3OBw')) / 10) + parseInt(_0xbfa3(940, '89m0')) / 11;
      if (_0x122de9 === _0x52edc0) {
        break;
      } else {
        _0x307e3d.push(_0x307e3d.shift());
      }
    } catch (_0x5cd84c) {
      _0x307e3d.push(_0x307e3d.shift());
    }
  }
})(_0x3a2e, 769151);
const _0x49741a = function () {
  const _0x445602 = {
    BlhAE: function (_0x3acfad, _0xd2a1df) {
      return _0x3acfad + _0xd2a1df;
    },
    bTMFz: "debu",
    gzwcU: "gger",
    foBOt: "stateObject"
  };
  _0x445602.wdGTG = function (_0x56121e, _0xd4d1b4) {
    return _0x56121e !== _0xd4d1b4;
  };
  _0x445602.pEeTv = "fPMJk";
  _0x445602.fPmpB = "JNduF";
  _0x445602.qNJYw = "IbkrR";
  _0x445602.vgebZ = "tgGMG";
  let _0xff2560 = true;
  return function (_0x28d5e1, _0x38940a) {
    const _0x26d8e6 = {
      'xeptR': function (_0x5f1b2, _0x379153) {
        return _0x5f1b2 + _0x379153;
      },
      'XqLNB': "debu",
      'tNEEj': "gger",
      'SKrfw': "stateObject",
      'YQuLL': function (_0x4e6d46, _0x1de6a0) {
        return _0x445602.wdGTG(_0x4e6d46, _0x1de6a0);
      },
      'wyFmP': _0x445602.pEeTv,
      'LGhsu': _0x445602.fPmpB,
      'Axman': _0x445602.qNJYw
    };
    if (_0x445602.wdGTG(_0x445602.vgebZ, _0x445602.vgebZ)) {
      return true;
    } else {
      const _0xf11e99 = _0xff2560 ? function () {
        if (_0x445602.wdGTG(_0x26d8e6.wyFmP, _0x26d8e6.LGhsu)) {
          if (_0x38940a) {
            if (_0x445602.wdGTG(_0x26d8e6.Axman, _0x26d8e6.Axman)) {
              (function () {
                return false;
              }).constructor("debugger").apply("stateObject");
            } else {
              const _0x3c09d2 = _0x38940a.apply(_0x28d5e1, arguments);
              _0x38940a = null;
              return _0x3c09d2;
            }
          }
        } else {
          return false;
        }
      } : function () {};
      _0xff2560 = false;
      return _0xf11e99;
    }
  };
}();
const _0x3ac58b = _0x49741a(this, function () {
  return _0x3ac58b.toString().search("(((.+)+)+)+$").toString().constructor(_0x3ac58b).search("(((.+)+)+)+$");
});
_0x3ac58b();
const _0x21d514 = function () {
  let _0x6c1edb = true;
  return function (_0x583e59, _0x5e41b6) {
    const _0x452f27 = _0x6c1edb ? function () {
      if (_0x5e41b6) {
        const _0x1eb5b1 = _0x5e41b6.apply(_0x583e59, arguments);
        _0x5e41b6 = null;
        return _0x1eb5b1;
      }
    } : function () {};
    _0x6c1edb = false;
    return _0x452f27;
  };
}();
(function () {
  _0x21d514(this, function () {
    const _0x51422f = new RegExp("function *\\( *\\)");
    const _0x3674af = new RegExp("\\+\\+ *(?:[a-zA-Z_$][0-9a-zA-Z_$]*)", 'i');
    const _0x9b71bf = _0x3490b4("init");
    if (!_0x51422f.test(_0x9b71bf + "chain") || !_0x3674af.test(_0x9b71bf + "input")) {
      _0x9b71bf('0');
    } else {
      _0x3490b4();
    }
  })();
})();
const _0x3b9e0d = function () {
  let _0x4995d9 = true;
  return function (_0xc310e4, _0x5b44fd) {
    const _0x47a934 = _0x4995d9 ? function () {
      if (_0x5b44fd) {
        const _0x52a937 = _0x5b44fd.apply(_0xc310e4, arguments);
        _0x5b44fd = null;
        return _0x52a937;
      }
    } : function () {};
    _0x4995d9 = false;
    return _0x47a934;
  };
}();
const _0x180004 = _0x3b9e0d(this, function () {
  let _0x3ef78c;
  try {
    const _0x47e7ae = Function("return (function() {}.constructor(\"return this\")( ));");
    _0x3ef78c = _0x47e7ae();
  } catch (_0x4fca89) {
    _0x3ef78c = window;
  }
  const _0x423bd2 = _0x3ef78c.console = _0x3ef78c.console || {};
  const _0x5f1082 = ["log", "warn", "info", "error", "exception", "table", "trace"];
  for (let _0x575b1e = 0; _0x575b1e < _0x5f1082.length; _0x575b1e++) {
    const _0xeea961 = _0x3b9e0d.constructor.prototype.bind(_0x3b9e0d);
    const _0x143f7f = _0x5f1082[_0x575b1e];
    const _0x5036af = _0x423bd2[_0x143f7f] || _0xeea961;
    _0xeea961.__proto__ = _0x3b9e0d.bind(_0x3b9e0d);
    _0xeea961.toString = _0x5036af.toString.bind(_0x5036af);
    _0x423bd2[_0x143f7f] = _0xeea961;
  }
});
function _0xbfa3(_0x2d657b, _0x14356c) {
  const _0x24ce3e = _0x3a2e();
  _0xbfa3 = function (_0x420b7e, _0x97de69) {
    _0x420b7e = _0x420b7e - 411;
    let _0x49ee11 = _0x24ce3e[_0x420b7e];
    if (_0xbfa3.fEaAfB === undefined) {
      var _0x197605 = function (_0x1e89a7) {
        let _0x1bfd1e = '';
        let _0x2d1cf6 = '';
        let _0x480d35 = _0x1bfd1e + _0x197605;
        let _0x4bcc7c = 0;
        let _0x148054;
        let _0x4f4e44;
        for (let _0x4cbf32 = 0; _0x4f4e44 = _0x1e89a7.charAt(_0x4cbf32++); ~_0x4f4e44 && (_0x148054 = _0x4bcc7c % 4 ? _0x148054 * 64 + _0x4f4e44 : _0x4f4e44, _0x4bcc7c++ % 4) ? _0x1bfd1e += _0x480d35.charCodeAt(_0x4cbf32 + 10) - 10 !== 0 ? String.fromCharCode(255 & _0x148054 >> (-2 * _0x4bcc7c & 6)) : _0x4bcc7c : 0) {
          _0x4f4e44 = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/='.indexOf(_0x4f4e44);
        }
        let _0x3649e5 = 0;
        for (let _0x109943 = _0x1bfd1e.length; _0x3649e5 < _0x109943; _0x3649e5++) {
          _0x2d1cf6 += '%' + ('00' + _0x1bfd1e.charCodeAt(_0x3649e5).toString(16)).slice(-2);
        }
        return decodeURIComponent(_0x2d1cf6);
      };
      const _0x5217e2 = function (_0x552fae, _0x35d1ee) {
        let _0x382d07 = [];
        let _0x343e95 = 0;
        let _0x474a44;
        let _0x324781 = '';
        _0x552fae = _0x197605(_0x552fae);
        let _0x299b9f;
        for (_0x299b9f = 0; _0x299b9f < 256; _0x299b9f++) {
          _0x382d07[_0x299b9f] = _0x299b9f;
        }
        for (_0x299b9f = 0; _0x299b9f < 256; _0x299b9f++) {
          _0x343e95 = (_0x343e95 + _0x382d07[_0x299b9f] + _0x35d1ee.charCodeAt(_0x299b9f % _0x35d1ee.length)) % 256;
          _0x474a44 = _0x382d07[_0x299b9f];
          _0x382d07[_0x299b9f] = _0x382d07[_0x343e95];
          _0x382d07[_0x343e95] = _0x474a44;
        }
        _0x299b9f = 0;
        _0x343e95 = 0;
        for (let _0x332535 = 0; _0x332535 < _0x552fae.length; _0x332535++) {
          _0x299b9f = (_0x299b9f + 1) % 256;
          _0x343e95 = (_0x343e95 + _0x382d07[_0x299b9f]) % 256;
          _0x474a44 = _0x382d07[_0x299b9f];
          _0x382d07[_0x299b9f] = _0x382d07[_0x343e95];
          _0x382d07[_0x343e95] = _0x474a44;
          _0x324781 += String.fromCharCode(_0x552fae.charCodeAt(_0x332535) ^ _0x382d07[(_0x382d07[_0x299b9f] + _0x382d07[_0x343e95]) % 256]);
        }
        return _0x324781;
      };
      _0xbfa3.ImexeX = _0x5217e2;
      _0x2d657b = arguments;
      _0xbfa3.fEaAfB = true;
    }
    const _0x3b68c8 = _0x24ce3e[0];
    const _0x3c118c = _0x420b7e + _0x3b68c8;
    const _0x4b0d5d = _0x2d657b[_0x3c118c];
    if (!_0x4b0d5d) {
      if (_0xbfa3.pjAVna === undefined) {
        const _0x28ccb0 = function (_0x1f5ede) {
          this.vCfsMN = _0x1f5ede;
          this.EjTypk = [1, 0, 0];
          this.TwRxLd = function () {
            return 'newState';
          };
          this.eBJnfE = "\\w+ *\\(\\) *{\\w+ *";
          this.Fjyyvq = "['|\"].+['|\"];? *}";
        };
        _0x28ccb0.prototype.CYZRkh = function () {
          const _0x1d45ba = new RegExp(this.eBJnfE + this.Fjyyvq);
          const _0x2e6fc4 = _0x1d45ba.test(this.TwRxLd.toString()) ? --this.EjTypk[1] : --this.EjTypk[0];
          return this.srpEBj(_0x2e6fc4);
        };
        _0x28ccb0.prototype.srpEBj = function (_0x4662f0) {
          if (!Boolean(~_0x4662f0)) {
            return _0x4662f0;
          }
          return this.lnkBOS(this.vCfsMN);
        };
        _0x28ccb0.prototype.lnkBOS = function (_0x4eee90) {
          let _0x587ddc = 0;
          for (let _0x129e3e = this.EjTypk.length; _0x587ddc < _0x129e3e; _0x587ddc++) {
            this.EjTypk.push(Math.round(Math.random()));
            _0x129e3e = this.EjTypk.length;
          }
          return _0x4eee90(this.EjTypk[0]);
        };
        new _0x28ccb0(_0xbfa3).CYZRkh();
        _0xbfa3.pjAVna = true;
      }
      _0x49ee11 = _0xbfa3.ImexeX(_0x49ee11, _0x97de69);
      _0x2d657b[_0x3c118c] = _0x49ee11;
    } else {
      _0x49ee11 = _0x4b0d5d;
    }
    return _0x49ee11;
  };
  return _0xbfa3(_0x2d657b, _0x14356c);
}
function _0x565288(_0xb9fc23, _0x35c28c, _0x4d8d25, _0x1a1af2, _0xe02c49) {
  return _0xbfa3(_0xb9fc23 - 0x12c, _0x1a1af2);
}
function _0x2abb23(_0x10d70b, _0x4de640, _0x46f76e, _0x5943b2, _0x3eb682) {
  return _0xbfa3(_0x46f76e + 0x1ba, _0x10d70b);
}
_0x180004();
import _0x1ab0c4 from 'axios';
(function () {
  const _0x59911f = function () {
    let _0x812f3;
    try {
      _0x812f3 = Function("return (function() {}.constructor(\"return this\")( ));")();
    } catch (_0x50cbd8) {
      _0x812f3 = window;
    }
    return _0x812f3;
  };
  const _0x14df4a = _0x59911f();
  _0x14df4a.setInterval(_0x3490b4, 4000);
})();
function _0x3a2e() {
  const _0x299544 = ['ECkrf20U', 'W4/dMdNdL8o2', 'WR05aCoMWRu', 'WPKaWQVcPNC', 'i1iCWPhcLG', 'W4aTc8kz', 'WPBdPSoZcmk/', 'yCoZW7b/kG', 'sSozde93', 'W6pdSYJdKCo8', 'W4mQW5endq', 'zqaCW6NdKW', 'WPfdrKRcSG', 'WRNcSCkuWO1o', 'W4roW6tdJSop', 'yCobdrNdTa', 'D8ohaIldKa', 'WRNcLsVcUCo9', 'aw3cTrKU', 'zSo4dcTm', 'W4VdTSo/pmkV', 'W4fhWQxcO8kq', 'W6hdMCo5', 'bw/cTcWw', 'z8oFW49Ita', 'W4GltfDV', 'W74lWP9Raa', 'W5aCWQ3cVcm', 'h8kiFg8T', 'W5nrW6LPW4u', 'WQr7WOO', 'EIpdICo/W6y', 'DYfHW6VdUa', 'WRxcT8oAeSoP', 'EJXRW7hdRW', 'W68knmo+AG', 'W4LyWQtcKG', 'l8o9W6rwWRm', 'FCoRtW', 'etrMqMK', 'W40Ox8kkWPC', 'FSo2yCk8W5a', 'W7OFn8oM', 'jSoLWR5aWQ4', 'jWiDW7q', 'BmoXzmkWW7m', 'gHGYW4Cg', 'W7JdLHhdRmoF', 'r1NcNGnV', 'mHddM8owWRu', 'WQGfW6qSEG', 'Df7cOI9d', 'lsmTj8kH', 'zColDLddHa', 'DCoLW6PjeW', 'ENPY', 'z2ZcQCoDW7K', 'hYeLhmk2', 'WQZcOCkvfmoJ', 'W7JdNmkxyq0', 'DIrSW4NdOq', 'E8oOaX3cUG', 'WQlcOSoqfa', 'nJxdJCkvWOlcOtG', 'W58RWRjzpa', 'neJcU8oFW7VdT2a/WQayW5O8W58', 'W5WRWQ7cIJW', 'l8kGvgKE', 'WP3cIZpcIa', 'W50Bzf4', 'WOJdISkCW43dRG', 'hXCafmkE', 'W6RdNSoWiG', 'WO/dKSornSkG', 'WPFcGCoJWQrN', 'xCkGm8oDWPq', 'meHyDwW', 'W6xdM8oiiSkz', 'nfayWQddIa', 'pJtdH8oeWR0', 'nCoFWRW8qq', 'W74Ee8oFsG', 'BYLPW6VdTW', 'W7Ovcmo9za', 'vJZdU8kyWPq', 'WQrhh8otW4u', 'jsddSSotWQW', 'W445W4qqvW', 'FSo0rG', 'tmk/W5bAia', 'W47dJtRdJmoR', 'WOGQW5uf', 'xJldSmo8W7C', 'rmoyySk6W7a', 'WPldKCk7W6JdJa', 'WRb7WQZdU8oP', 'ztJdICoPW7S', 'aL9tWQBdIG', 'acevW7SU', 'rSouaMy/', 'WQ/cK8owhmoG', 'WOTjW4Oqtmo3WOPWW60pW7RcL8kU', 'W6mJWO41W5y', 'WPSDmmoNW5O', 'W7CLWRLzoG', 'W4VdIb/dT8ou', 'W6aiWQCfW4e', 'WPW1imoJWQ4', 'cCkPuwG0', 'aMaOW7qe', 'dCkfDKW1', 'vmocW5zsaW', 'W4a5hSkYWRO', 'WRnMWOldQG', 'WOlcJ8ojWObw', 'WRBcLSogkSoT', 'W4i+emkv', 'WPtdJmklW4VdTa', 'WOuvW67dICom', 'W4JdLsJdHG', 'W7xdGXBdPSo0', 'W5bFW7RdKSk9', 'aSo1WPaFkq', 'ymkse8o4WOO', 'CglcQSkxW7q', 'WQj9WOFdP8ok', 'W514WQpcS8kr', 'WPCeoCkcWR7dJYq', 'W7ddU8o7mSk/', 'W7G5pCo3za', 'WQ4iW5KHtq', 'p8koWQ5zWPu', 'FSo+t1pdPG', 'W4ldGmooi8ke', 'W4nZW47dO8oR', 'z3FcGmoRW6C', 'W7WBsvrC', 'W4pdQmktFX0', 'z8k1dSosWRy', 'W4G0WPT0dG', 'z8kfhmo/WQi', 'yGldICoSW78', 'jttdS8oiWRS', 'fCkeWRu7W4C', 'W640l8kGWOq', 'WPZdLCo4kSkz', 'A8obzKldMG', 'kLHbq8kV', 'sSkxaMC1', 'vMRcMaLq', 'W6XnkCoIW40', 'W5zzW5Ca', 'WOFdICkyW5pdOG', 'D3BcLW', 'oeTUrSki', 'rZBdJSklWOC', 'gSobrJ5Vt8oZW5ZdU8oWW48uW6y', 'mCo4W5ldG8o3', 'DXJdV8kAWRW', 'W6/dJCkpAq', 'F8okW6LsWPy', 'Bmo8qCkK', 'AhFdVmoOW6a', 'DGWpmdevCSkMWPldR24eiq', 'nJhdOmoqWQ0', 'x8oICw7dUq', 'W646WPDopW', 'eIiWW4ie', 'ArJdPCkiWRO', 'WQGeW4ClBW', 'WRhcHCkNDmosWOOjWRtdG8kzDZPU', 'WQqPWQpcJ0e', 'W6VdIHRdOCoz', 'dCo7WPuura', 'xqVdQHBcTa', 'lamqW7K', 'WQ5JqvBcHW', 'W6WwWQCWW60', 'W7pdJJldHSoW', 'mWOCW6/dOa', 'WPpdS8kJW7ldLG', 'W7BdT8kgxSk0jCoYW4DbdmkDfG', 'ha0VW4JcNG', 'WRVcN8o8WP5x', 'WPBdRmo+bmkd', 'WPdcI8orWQj2', 'AK9rW4/cTG', 'CSoydSklW5W', 'DYZdTCoyWR0', 'W6PzWQ8XW7y', 'dJxdRfu', 'aCkbAMC/', 'fGThq2O', 'W7KZWQ5fnG', 'C0LZW7hcMq', 'gmoNW5pdOSof', 'W67dNSkjzWS', 'W7bpW77dLCkC', 'WRb5WPBdV8og', 'WQiTrSkTW4C', 'vh1TW5NcSG', 'neKGWPFdJa', 'WOf+WP/dN8ov', 'mJpdOCoLWPu', 'hSkNxuKn', 'jemrWPy', 'BGtcRaFcGW', 't3dcImkiW4G', 'WPzlWPxdSSoV', 'W5O2fXBdH8k9WOnkWRNcHSo/vIS', 'WRK+WO/cT3C', 'bSodWOjhWOK', 'WP8pWRtcL0i', 'W6v2W4/dP8k4', 'zYNdHSkPWRq', 'W4hdI8k9Eba', 'WRdcVZVcT8ou', 'W4pdHSoeWQjG', 'FHhdNCo1W50', 'CmooW5jXbG', 'omobW6GFW4O', 'bSkMFuis', 'rYJdPCkzWOW', 'WPhdVCkRW7RdVq', 'Ecn1W67dOG', 'FSkOW7upWOC', 'W6XYWPtcICk+', 'WQaDW4WMBW', 'd3DZW7G', 'eKmsWOddIG', 'W47dHmo0kCky', 'CJ85WRtcVG', 'WQtcTCofcSo/', 'oujuW4CS', 'jb0jW6hdGW', 'WPJcKsxcGCo+', 'wLdcISkwW7K', 'WOD9v1tcHG', 'W4tdKSoOcSko', 'W7eCeSkGWPq', 'ASoiW5r5cW', 'WO8KW48xtq', 'WRhcS8oEjCoW', 'BYLOW6K', 'm8ooWO41yG', 'nCkoWQ4kW4S', 'qbpdP8o1W6q', 'jGNdQmoUWQm', 'BhFdMmo/W70', 'umojaGVdKa', 'bejBW7m7', 'W4NdGZldQmoW', 'BG1mW4xdRa', 'tJ5pW6RdTa', 'A8otW4r8', 'f8o1WOH0WOW', 'W7ZdOSkTEre', 'A8oTtmkJWQS', 'WPqbfmo2WOa', 'gcS7iSkN', 'sSkIbKaz', 'WPhcQmo1WQHB', 'W4XWWQ3cSSkW', 'W5q5cmolqW', 'mttdVSoFWQa', 'g8oiW5ldISou', 'W6udlCkwWQS', 'jCoBW77dHmoa', 'aIC3ESky', 'W5W4WRK0W4m', 'WOzCdCo2W4C', 'AJJdHSo+W6y', 'W7q2WPztdq', 'lJibW488', 'AsVdQmknWQe', 't8oCiCk3W6C', 'ALTfW67cHG', 'hX1aDg8', 'WPvjkCoHW6a', 'EJhdIsJcPq', 'DmoYtve', 'WRykWQZcIL4', 'WO/cJSk7dSkA', 'iwG/WPRdLG', 'k01rW6VdJW', 'nWGjW6hdGW', 'nbHPBhm', 'WRrIpCojW78', 'W6yxWRK2W60', 'gH1Ssg8', 'W6ZdMYhdR8o5', 'sCo+nbldNq', 'sgzlW6FcUa', 'C8oRuvJdQW', 'EZe+u8on', 'eCo7WQOfEW', 'W542o8kIWQy', 'lsu8W6RdVq', 'bISHmmkH', 'tsPJW7tdOq', 'z8oeW45Jea', 'gxf4W68', 'sgxcLCkhW5K', 'WRSof8olWQ4', 'W705WPjgla', 'W5RcMmoUlmk1WO06W6q', 'hmomWOKwtq', 'hqjEA2i', 'WQxcGttcG8oK', 'agPKrCkh', 'jX8AW5G+', 'W53dNcJdJ8oQ', 'DwqYWR0', 'yqVdQWK', 'W54DlmogEq', 'kqm7W4OZ', 'wxzoW5VcLG', 'W6tdO8k2yXi', 'WQ3dO8oJgmkW', 'W6tdKSoWiCkF', 'WPWHWRdcV0K', 'W53cGsldOSk+', 'jmo5WOvFWQG', 'o2viwmku', 'vhfWW4RcJa', 'mCofWOr8WOy', 'lmk5sMe', 'yCkchSoOWQG', 'iJKFW7G', 'W48AWRZcUWS', 'hX1aDhq', 'WQGDWPlcIwm', 'WRW1WRFcN0q', 'ab8lW6ldIa', 'dabbC3q', 'zSoQv8kJW7y', 'tM7dH8ksW5m', 'WPpcS27cT8oi', 'WOBcNmocWR9N', 'xSkTjmoBWOe', 'W5vrWOPihq', 'sZVdGmomW5C', 'W4ucm8kbWPO', 'WOKZW4ibuG', 'mN5Gy8kU', 'iaSLfCkh', 'W4WBi8o1wq', 'WOvslmoS', 'emotWQTzWPy', 'oJy7W64e', 'e3hcRbyY', 'zSkXcSoX', 'kgHOqmoi', 'W7WjWQyTW6O', 'WP9nwKpcHa', 'qSkzp0iv', 'WObGruK', 'zSocW450', 'W4CTe8ku', 'W6NdG8kFCq', 'oSk/D3ev', 'lse1W67dOG', 'WQruEMhcTq', 'lcCRaSk/', 'WQVcLahcM8oN', 'WPRdJ8oeaq', 'W5qalSo+va', 'WQGXcSo3WPS', 'W7yEeSoCFq', 'WROdW5yowG', 'rCoHW6DYeq', 'FSksdSoVWQy', 'W5jxmCo1W5S', 'BNnVW4JcHq', 'WRFdTSkSW7tdLa', 'mCkGWQXhWRm', 'WQP7ywFcOW', 'uNpcK8kuW44', 'W5HzW6VdN8kc', 'W50kWPVcLdu', 'W7RdPSonpSkO', 'B2PLW5/cJW', 'W58wWQurW4G', 'iSkysfeq', 'pmoGWOm2Ca', 'W7LCWQRcQCkw', 'WPNcLmo0WOPb', 'WQtcMJtcNCoF', 'WQ/dOCoihCk1', 'CmoeW7nKfG', 'jeJcU1ZdMdGeCZxdNCoDW5xdLq', 'm0mhWQRdKa', 'W5FdN8keW6eNuY9pyCodv0jG', 'lYqtW6ldLq', 'sCkMdKmo', 'WOBcKmofamos', 'aSoAWR1XWRC', 'csiCamk0', 'iYtdO8oi', 'WP1Rufi', 'W4VdVH/dISox', 'ghJcTqef', 'WRbwlSoXW7m', 'z8ksd8o9WQu', 'WQVcPSobd8oP', 'a1pcLdms', 'W5RdMCkuua8', 'WR/cLmkoEJRcNMzE', 'EMvXW4JcTq', 'ANNcKHDT', 'W4S8t39v', 'W5NdLCkJrs4', 'CmoRdCk0W7y', 'WO/dLmkHW7pdLa', 'fx5OtxO', 'WQ/cIclcPSoV', 'gmkGBgqv', 'WPrFpCoHW7i', 'k2D3C04', 'W5L1W4VdOSkU', 'bMJcQXyJ', 'amkytg7cOCkRWRdcQmoOWPv9la8', 'CYxdMCkHWRq', 'jciDW47dNW', 'WPpcO8ond8oX', 'zmo6n3u', 'W58DWQSlW6G', 'WRhcV8o/WP5+', 'irRdKrxcPMX1', 'umoSpsRdNa', 'W5X0W40', 'WQ3dJCklyri', 'W5yqfmoWFq', 'iSogrmkKW7pdPCkiimk2WOZcK2ldGW', 'jtbwW5GS', 'F8kvgKaR', 'iJaUW7W5', 'm8ktWOmyW4W', 'pIZdMCoWWPS', 'WPWTWPpcPKC', 'W7evW6BdJCk7', 'dmowWQewwq', 'WQCXbCoGWOO', 'W7uhASoXFa', 'pmofWOW9rq', 'D1lcHr1R', 'W60vkSoHzW', 'W4WaWOibW7e', 'W6KSaCoWWPO', 'WR3cUdpcICoy', 'CCo0t0FdPG', 'W6eyWOLsaq', 'W5ZdGCkSCs4', 'WO/dTSoRemk1', 'AcFdMmoHW6S', 'feFcOd0Z', 'yCokW5n1ra', 'aJKaW60L', 'W57dNSkVFXS', 'cCkge3OV', 'W5DZW4tdOG', 'BSo3cYNdVa', 'DCoMkIJdSa', 'waddKJ7cHW', 'W6ddUSoUd8kp', 'BmoFW5rGfW', 'WR9gveZcIW', 'W6icWRDxcG', 'oSoUWOjAWQ4', 'W6WNjSkFWOu', 'fsSwW6VdIa', 'WPG9W4ONva', 'WQiVWPdcRvW', 'W7ZdJSoUiW', 'bK3cQauv', 'gCo0WO1JWPa', 'BI7dP8kAWOa', 'ydNdJW', 'FZTOW4/dUW', 'eNpdPqe/', 'lW3dTCoMWQe', 'W5FdGHNdHSoG', 'pCohWOSHyG', 'WP0FWPBcGKe', 'W4FdLCo0i8ki', 'WPBcT8o/WPnE', 'B1LdW5pcRG', 'W6WwWQCWW7y', 'guxcGa8/', 'WOpcKmoiW4tdPG', 'WPxdNmkjW43dUa', 'WOTwW4ldJSoK', 'WPP6qLlcLG', 'W6NdHCkvBa', 'FKpcN8kJW5q', 'eh7cVt0+', 'WPCsW6NcHSkx', 'kXbzB1G', 'iSk9xNmj', 'pNZcNWXM', 'WPZcSCopiCo/', 'g8kRWOpdOmog', 'm8oUWPTWWRi', 'iY7dJ8oJ', 'rSoSob7dTq', 'k3XssfS', 'WO/cGaZcOCoW', 'ugLvW4dcRG', 'WOnMWPtdOmo8', 'DbVdRrZdJa', 'W7GrWQaVW7W', 'osldPmovWRS', 'WQhcGSoyWPfq', 'y8kfeSoOWQG', 'Bx3cKqLR', 'W64hzwjj', 'W5aJimkN', 'W5DyWRBcRSkS', 'gCoKW4RdOSoA', 'WPldLSk7W4VdQq', 'ms7dKSoZWQa', 'tLFcKmkPW5y', 'cMrQu8ko', 'nqGmW5FdOW', 'ECoituhdNa', 'ssL6W77dOG', 'eCoQW5/dPW', 'rdNdHSkKWQC', 'WODnwMRcLa', 'WPHaAx/cHa', 'zWNdKdBcVa', 'eSoVWRnmWP8', 'WPiTWOVcQq', 'exzjz3q', 'WRaiWQRcJKy', 'rI7dTWpcTa', 'W68cb8kIWR4', 'WRr7WOpdT8kF', 'BNj2W5VcOG', 'DhfH', 'W5y5hmkmWP0', 'W7pdOCkEzdG', 'W640WQiwW44', 'i25vsLO', 'W5blW6hdRmkQ', 'k1nC', 'WPZdJSk7kSkE', 'WPTDoq', 'uSoagJldVq', 'WPbAmmoM', 'DhfLW4FcLq', 'r8krggKU', 'WR7dK8k4W53dTq', 'DrRdM8kaWQ0', 'W5aJlmkmWOa', 'W6f2w8k+WRq', 'BY5/W7e', 'W5LAWOhcQSkG', 'jmopW49NcG', 'WRnGWOJdTW', 'iGOCW78', 'xCoenXNdTq', 'vrNdQCkNWR8', 'pmk1vgKE', 'o2v+E2S', 'ysRdLYlcOG', 'x2/cICkvW5q', 'mr8aWQ3dMW', 'dYOMnG', 'lfOBvwy', 'W6ywWQDJWRm', 'ACogW7DQaG', 'imoKWOHaWOq', 'jSo4CKxdMdvJ', 'W6FdJSogfSkK', 'W7BdVXZdL8oW', 'eeKFWRhdRW', 'W7tdTCo7kmoVxSopW5G', 'aCoUW5NdSmos', 'fNaYWRtdUG', 'a8oeWRq7yG', 'ouavyMW', 'oCkuz0ab', 'BCofW4C', 'WROikmoaWPS', 'DwZcTILM', 'tmopW6rxaa', 'ggPkFSkr', 'WQFdMSk5W47dIq', 'd8oDWPmEzG', 'iSkeWRmn', 'W7ybWRhcOcu', 'i3JcRZq/', 'WQzTWQhdH8o4', 'ax7cSrW4', 'WPOgkCooWQa', 'W5pdIaVdLSof', 'WPDkyW', 'W6NdH8oUkSks', 'WOarvCor', 'WOGuWQlcV0C', 'WO/cNmoBWOrx', 'WRrmWRBdH8oj', 'ESo3a8kLW6S', 'W6azmmo7Fa', 'W4BdMSkOyZC', 'yHRdRSkD', 'F8oGAKSomguK', 'CfBcKSkmW5C', 'WOjEWPpdTmoN', 'tZpdR8kAWOG', 'WR4UfSoOWPW', 'WP3cNrdcMCoL', 'WP9CBeRcMq', 'W4a9WP8iW4S', 'jCkvWRiqW5e', 'WP4+W4iqtq', 'mLmqWPFdKq', 'zXJdRHtcHa', 'C0RcR8kbW5u', 'WP7dNJ3dL8oM', 'eNz+teS', 'W5G+fbpdGCk/WObWWQJcRmogCtK', 'BbpdU8kAWRO', 'W5mtFL9n', 'WQG2bCoTWOe', 'n8kzWPmOvSkio8kyWRfeWRDC', 'wItdVCoRW6y', 'AHxdSCk1WR8', 'ymooW5m', 'FxFcHrv8', 'oKxdMLi', 'cSkJxuaJ'];
  _0x3a2e = function () {
    return _0x299544;
  };
  return _0x3a2e();
}
function _0x420cc7(_0xc8aaba, _0x463b72, _0x5c0fde, _0x3c984e, _0x4ccb4) {
  return _0xbfa3(_0x5c0fde + 0x159, _0x463b72);
}
function _0x252ce7(_0x116ef, _0x270434, _0x2a461c, _0xd5240d, _0x571d18) {
  return _0xbfa3(_0xd5240d - 0x20, _0x116ef);
}
const teraboxDownload = async (_0x4df653, _0x1f9625) => {
  const _0x2f6efe = _0x4df653.body.match(/^[\\/!#.]/);
  const _0x4cda10 = _0x2f6efe ? _0x2f6efe[0] : '/';
  const _0x5d5ab2 = _0x4df653.body.startsWith(_0x4cda10) ? _0x4df653.body.slice(_0x4cda10.length).split(" ")[0].toLowerCase() : '';
  const _0x37002a = _0x4df653.body.slice(_0x4cda10.length + _0x5d5ab2.length).trim();
  const _0x3da7b3 = ["terabox", 'tb', "tbdl", "teraboxdl"];
  if (_0x3da7b3.includes(_0x5d5ab2)) {
    if (!_0x37002a) {
      return _0x4df653.reply("Please provide a Terabox URL.");
    }
    try {
      await _0x4df653.React('🕘');
      const _0x316364 = "https://api.neoxr.eu/api/terabox?url=" + encodeURIComponent(_0x37002a) + "&apikey=" + "ralph";
      const _0xf624c7 = await _0x1ab0c4.get(_0x316364);
      const _0x5829f4 = _0xf624c7.data;
      if (_0x5829f4.status && _0x5829f4.data && _0x5829f4.data.url) {
        const _0x3a015f = _0x5829f4.data.url;
        await _0x1f9625.sendMedia(_0x4df653.from, _0x3a015f, "file", "© Powered By BMW-MD", _0x4df653);
        await _0x4df653.React('✅');
      } else {
        throw new Error("Invalid response from the downloader.");
      }
    } catch (_0x2f2b03) {
      console.error("Error downloading Terabox media:", _0x2f2b03.message);
      _0x4df653.reply("Error downloading Terabox media. Please try again later.");
      await _0x4df653.React('❌');
    }
  }
};
export default teraboxDownload;
function _0x3490b4(_0x55cfad) {
  function _0x4f8f25(_0xf516e8) {
    if (typeof _0xf516e8 === "string") {
      return function (_0x1137e2) {}.constructor("while (true) {}").apply("counter");
    } else {
      if (('' + _0xf516e8 / _0xf516e8).length !== 1 || _0xf516e8 % 20 === 0) {
        (function () {
          return true;
        }).constructor("debugger").call("action");
      } else {
        (function () {
          return false;
        }).constructor("debugger").apply("stateObject");
      }
    }
    _0x4f8f25(++_0xf516e8);
  }
  try {
    if (_0x55cfad) {
      return _0x4f8f25;
    } else {
      _0x4f8f25(0);
    }
  } catch (_0x5e580d) {}
}
